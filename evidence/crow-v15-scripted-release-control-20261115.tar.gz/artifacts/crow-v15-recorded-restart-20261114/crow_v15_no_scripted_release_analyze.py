from pathlib import Path
import json
r=Path("/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114");report={}
for seed in (20370113,20370127):
 old=r/f"v15-resetfixed-lr30x-continuation04-evaluation-{seed}-250";new=r/f"v15-no-scripted-release-continuation04-evaluation-{seed}-250";report[str(seed)]={}
 for name in ("baseline","candidate"):
  a=json.loads((old/(name+".json")).read_text())["payload"]["frames"];b=json.loads((new/(name+".json")).read_text())["payload"]["frames"];fields=("q","v","actor_observation","accepted_actions","body_states","reward","done","termination_reason","outcomes");assert len(a)==len(b)
  report[str(seed)][name]={k:{"first_difference":next((i+1 for i,(x,y) in enumerate(zip(a,b)) if x[k]!=y[k]),None),"different_frames":sum(x[k]!=y[k] for x,y in zip(a,b))} for k in fields}
report["scope"]="Different binaries with and without scripted release sequence; identical source reconstructed starts and policies; only first 250 resumed steps on two consumed development seeds. Not evidence of general balance or release.";(r/"no-scripted-release-comparison.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))
