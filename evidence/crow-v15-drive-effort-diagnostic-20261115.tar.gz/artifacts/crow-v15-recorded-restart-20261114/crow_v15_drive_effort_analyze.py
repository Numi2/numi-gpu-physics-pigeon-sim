from pathlib import Path
import json,numpy as np
r=Path("/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114/v15-resetfixed-effort-diagnostic-20370113-210")
def parse(n):
 e={};t={};flags=set()
 with (r/(n+".stderr")).open() as f:
  for line in f:
   if line.startswith("CROW_LEG_EFFORT "):
    x=line.split();step,sub,lane=map(int,x[1:4]);flags.add(tuple(map(int,x[4:7])));e[(step,sub)]=[float(x[7+i*5]) for i in range(6)]
   elif line.startswith("CROW_DRIVE_TARGET "):
    x=line.split();t[int(x[1])]=[float(x[3+j]) for j in list(range(13,19))+list(range(22,38))]
 return e,t,sorted(flags)
b,bt,bf=parse("baseline");h,ht,hf=parse("high_rate");steps=151;keys=[(i,j) for i in range(1,steps+1) for j in range(16)];assert all(x in b and x in h for x in keys) and all(i in bt and i in ht for i in range(1,steps+1));be=np.array([b[x] for x in keys]);he=np.array([h[x] for x in keys]);bta=np.array([bt[i] for i in range(1,steps+1)]);hta=np.array([ht[i] for i in range(1,steps+1)]);legnames=["left_hip","left_knee","left_ankle","right_hip","right_knee","right_ankle"]
report={"flags":{"baseline":bf,"high_rate":hf},"compared_steps":steps,"substeps_per_step":16,"first_step_target_difference_rad":(hta[0]-bta[0]).tolist(),"target_difference_rms_rad":np.sqrt(np.mean((hta-bta)**2,axis=0)).tolist(),"leg_effort_difference_rms":dict(zip(legnames,np.sqrt(np.mean((he-be)**2,axis=0)).tolist())),"baseline_leg_effort_abs_max":dict(zip(legnames,np.max(np.abs(be),axis=0).tolist())),"high_rate_leg_effort_abs_max":dict(zip(legnames,np.max(np.abs(he),axis=0).tolist())),"scope":"Observed drive targets and applied effort at each native substep through the high-rate first failure, after diverging feedback. Parity with uninstrumented runs is checked separately. Maxima do not alone establish actuator saturation or biological fidelity."};(r/"effort-analysis.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))
