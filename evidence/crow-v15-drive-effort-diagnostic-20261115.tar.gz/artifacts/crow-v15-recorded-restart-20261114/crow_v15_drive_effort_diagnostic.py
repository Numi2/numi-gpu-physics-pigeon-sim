from pathlib import Path
import json,os,subprocess,hashlib,time
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";b=r/"build/crow-v15-recorded-restart-20261114";source=a/"v15-resetfixed-checkpoint-roundtrip-20370113-49-100";o=a/"v15-resetfixed-effort-diagnostic-20370113-210";o.mkdir(exist_ok=False);cmd=json.loads((source/"resume.command.json").read_text());cmd[0]=str(b/"v15-checkpoint-fork-prototype/metalrobo_task_rollout");candidate=b/"v15-resetfixed-training-20370113-horizon256-lr1000x-fresh-v2.policypack.deployment.policypack";rows=[]
for name,fork in (("baseline",None),("high_rate",candidate)):
 c=cmd.copy();c[c.index("--steps")+1]="210";c[c.index("--state-trace")+1]=str(o/(name+".tsv"));c[c.index("--crow-replay-pack")+1]=str(o/(name+".json"));env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/"v15-checkpoint-effort-prototype"),CROW_EXPERIMENT_GAIT_SMOOTH="1",CROW_SUBSTEP_TRACE="1");env.pop("CROW_RECORDED_STATE_RESTART",None);env.pop("CROW_CHECKPOINT_FORK_POLICY",None)
 if fork:env["CROW_CHECKPOINT_FORK_POLICY"]=str(fork)
 (o/(name+".command.json")).write_text(json.dumps({"argv":c,"fork_policy":str(fork) if fork else None,"substep_trace":True},indent=2)+"\n");t=time.time()
 with (o/(name+".stdout")).open("w") as so,(o/(name+".stderr")).open("w") as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 rows.append({"name":name,"exit_code":q.returncode,"seconds":time.time()-t});(o/"results.json").write_text(json.dumps(rows,indent=2)+"\n");print(rows[-1],flush=True)
 if q.returncode:raise SystemExit(q.returncode)
for name,ref in (("baseline",a/"v15-resetfixed-lr1000x-fresh-v2-evaluation-20370113-250/baseline.json"),("high_rate",a/"v15-resetfixed-lr1000x-fresh-v2-evaluation-20370113-250/candidate.json")):
 x=json.loads((o/(name+".json")).read_text())["payload"]["frames"];y=json.loads(ref.read_text())["payload"]["frames"][:len(x)];fields=("q","v","actor_observation","accepted_actions","body_states","reward","done","termination_reason","outcomes");diff={k:sum(u[k]!=v[k] for u,v in zip(x,y)) for k in fields};(o/(name+".parity.json")).write_text(json.dumps(diff,indent=2)+"\n");print(name,"parity",diff,flush=True)
 if any(diff.values()):raise SystemExit("observer changed trajectory")
