from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";o=a/"v15-wholebody-v2";b=r/"build/crow-v15-recorded-restart-20261114";source=a/"v15-resetfixed-checkpoint-roundtrip-20370113-49-100";prefix=json.loads((source/"prefix.command.json").read_text());resume=json.loads((source/"resume.command.json").read_text());keys=("q","v","actor_observation","accepted_actions","body_states","reward","done","termination_reason","outcomes");rows=[]
for variant in ("null","probe","neural"):
 for phase in ("prefix","resume"):
  name=variant+"-"+phase;c=(prefix if phase=="prefix" else resume).copy();c[0]=str(b/"v15-checkpoint-fork-prototype/metalrobo_task_rollout");c[c.index("--metallib")+1]=str(b/"v15-wholebody-v2"/(variant+".metallib"));c[c.index("--steps")+1]="49" if phase=="prefix" else "50";c[c.index("--state-trace")+1]=str(o/(name+".tsv"));c[c.index("--crow-replay-pack")+1]=str(o/(name+".json"));opt="--save-life-checkpoint" if phase=="prefix" else "--resume-life-checkpoint";c[c.index(opt)+1]=str(o/(variant+".chk"))
  env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/"v15-checkpoint-effort-prototype"),CROW_EXPERIMENT_GAIT_SMOOTH="1");env.pop("CROW_RECORDED_STATE_RESTART",None);env.pop("CROW_CHECKPOINT_FORK_POLICY",None)
  if phase=="resume":env["CROW_SUBSTEP_TRACE"]="1"
  (o/(name+".command.json")).write_text(json.dumps({"argv":c,"trace":phase=="resume"},indent=2)+"\n");t=time.time()
  with (o/(name+".stdout")).open("w") as so,(o/(name+".stderr")).open("w") as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
  rows.append({"name":name,"exit_code":q.returncode,"elapsed":time.time()-t});(o/"screen-runs.json").write_text(json.dumps(rows,indent=2)+"\n");print(rows[-1],flush=True)
  if q.returncode:raise SystemExit(q.returncode)
  if phase=="prefix":
   got=json.loads((o/(name+".json")).read_text())["payload"]["frames"];ref=json.loads((source/"prefix.json").read_text())["payload"]["frames"];assert len(got)==len(ref)==49;diff={k:sum(x[k]!=y[k] for x,y in zip(got,ref)) for k in keys};(o/(variant+"-prefix-parity.json")).write_text(json.dumps(diff,indent=2)+"\n");print(name,diff,flush=True)
   if any(diff.values()):raise SystemExit("variant prefix differs from prior physical start")
ref=json.loads((a/"v15-wholebody-v1/baseline.json").read_text())["payload"]["frames"];null=json.loads((o/"null-resume.json").read_text())["payload"]["frames"];probe=json.loads((o/"probe-resume.json").read_text())["payload"]["frames"];assert len(ref)==len(null)==len(probe)==50;diff={k:sum(x[k]!=y[k] for x,y in zip(ref,null)) for k in keys}
def targets(path):
 d={}
 for line in path.read_text().splitlines():
  p=line.split()
  if p and p[0]=="CROW_DRIVE_TARGET":d[int(p[1])]=list(map(float,p[3:]))
 return d
base=targets(a/"v15-wholebody-v1/baseline.stderr");pr=targets(o/"probe-resume.stderr");steps=[]
for step in sorted(set(base)&set(pr)):
 delta=[y-x for x,y in zip(base[step],pr[step])];changed={str(i):v for i,v in enumerate(delta) if abs(v)>1e-5}
 if changed:steps.append({"step":step,"target_differences_rad":changed})
report={"baseline_null_differing_frames":diff,"probe_first_observation_equal":ref[0]["actor_observation"]==probe[0]["actor_observation"],"probe_first_q_equal":ref[0]["q"]==probe[0]["q"],"probe_first_v_equal":ref[0]["v"]==probe[0]["v"],"probe_first_changed_target":steps[0] if steps else None};(o/"screen-parity.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2),flush=True)
if any(diff.values()):raise SystemExit("null differs from baseline")
if not steps:raise SystemExit("probe had no measurable target change")
