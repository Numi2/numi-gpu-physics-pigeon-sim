from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";o=a/"v15-wholebody-v2";b=r/"build/crow-v15-recorded-restart-20261114";keys=("q","v","actor_observation","accepted_actions","body_states","reward","done","termination_reason","outcomes");rows=[];env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/"v15-checkpoint-effort-prototype"),CROW_EXPERIMENT_GAIT_SMOOTH="1");env.pop("CROW_RECORDED_STATE_RESTART",None);env.pop("CROW_CHECKPOINT_FORK_POLICY",None)
def run(name,c):
 (o/(name+".command.json")).write_text(json.dumps(c,indent=2)+"\n");t=time.time()
 with (o/(name+".stdout")).open("w") as so,(o/(name+".stderr")).open("w") as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 rows.append({"name":name,"exit_code":q.returncode,"elapsed":time.time()-t});(o/"evaluation-runs.json").write_text(json.dumps(rows,indent=2)+"\n");print(rows[-1],flush=True)
 if q.returncode:raise SystemExit(q.returncode)
for seed,split in ((20370113,49),(20370127,50)):
 source=a/f"v15-resetfixed-checkpoint-roundtrip-{seed}-{split}-100";ck=o/("neural.chk" if split==49 else "easy-neural.chk")
 if split==50:
  c=json.loads((source/"prefix.command.json").read_text());c[0]=str(b/"v15-checkpoint-fork-prototype/metalrobo_task_rollout");c[c.index("--metallib")+1]=str(b/"v15-wholebody-v2/neural.metallib");c[c.index("--state-trace")+1]=str(o/"easy-prefix.tsv");c[c.index("--crow-replay-pack")+1]=str(o/"easy-prefix.json");c[c.index("--save-life-checkpoint")+1]=str(ck);run("easy-prefix",c)
  ref=json.loads((source/"prefix.json").read_text())["payload"]["frames"];got=json.loads((o/"easy-prefix.json").read_text())["payload"]["frames"];assert len(ref)==len(got)==50;d={k:sum(x[k]!=y[k] for x,y in zip(ref,got)) for k in keys};(o/"easy-prefix-parity.json").write_text(json.dumps(d,indent=2)+"\n");print("easy prefix",d,flush=True)
  if any(d.values()):raise SystemExit("easy prefix mismatch")
 for name in (("neural",) if split==49 else ("baseline","neural")):
  tag=f"{seed}-{name}-400";c=json.loads((source/"resume.command.json").read_text());c[0]=str(b/"v15-checkpoint-fork-prototype/metalrobo_task_rollout");c[c.index("--steps")+1]="400";c[c.index("--state-trace")+1]=str(o/(tag+".tsv"));c[c.index("--crow-replay-pack")+1]=str(o/(tag+".json"))
  if name=="neural":c[c.index("--metallib")+1]=str(b/"v15-wholebody-v2/neural.metallib");c[c.index("--resume-life-checkpoint")+1]=str(ck)
  run(tag,c)
results={}
for seed,split in ((20370113,49),(20370127,50)):
 results[str(seed)]={}
 for name in (("neural",) if split==49 else ("baseline","neural")):
  tag=f"{seed}-{name}-400";fs=json.loads((o/(tag+".json")).read_text())["payload"]["frames"];done=next((i+1 for i,x in enumerate(fs) if x["done"]),None);valid=fs[:done] if done else fs;first=valid[:250];results[str(seed)][name]={"first_done_relative":done,"first_done_absolute":split+done if done else None,"first_250_max_tilt":max(x["tilt"] for x in first),"frames":len(fs),"maximum_new_action_by_slot":[max(abs(x["accepted_actions"][j]) for x in valid) for j in range(8,18)]}
(o/"evaluation-summary.json").write_text(json.dumps(results,indent=2)+"\n");print(json.dumps(results,indent=2),flush=True)
