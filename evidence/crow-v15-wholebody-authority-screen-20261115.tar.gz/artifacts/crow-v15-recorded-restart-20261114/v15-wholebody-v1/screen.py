from pathlib import Path
import json,os,subprocess,hashlib,time
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";o=a/"v15-wholebody-v1";b=r/"build/crow-v15-recorded-restart-20261114";source=a/"v15-resetfixed-checkpoint-roundtrip-20370113-49-100";base=json.loads((source/"resume.command.json").read_text());base[0]=str(b/"v15-checkpoint-fork-prototype/metalrobo_task_rollout");rows=[]
for name in ("baseline","null","probe"):
 c=base.copy();c[c.index("--steps")+1]="50";c[c.index("--state-trace")+1]=str(o/(name+".tsv"));c[c.index("--crow-replay-pack")+1]=str(o/(name+".json"))
 if name!="baseline":c[c.index("--metallib")+1]=str(b/"v15-wholebody-v1"/(name+".metallib"))
 env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/"v15-checkpoint-effort-prototype"),CROW_EXPERIMENT_GAIT_SMOOTH="1",CROW_SUBSTEP_TRACE="1");env.pop("CROW_RECORDED_STATE_RESTART",None);env.pop("CROW_CHECKPOINT_FORK_POLICY",None)
 (o/(name+".command.json")).write_text(json.dumps({"argv":c,"overrides":{k:env[k] for k in ("DYLD_LIBRARY_PATH","CROW_EXPERIMENT_GAIT_SMOOTH","CROW_SUBSTEP_TRACE")}},indent=2)+"\n");t=time.time()
 with (o/(name+".stdout")).open("w") as so,(o/(name+".stderr")).open("w") as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 rows.append({"name":name,"exit_code":q.returncode,"elapsed":time.time()-t});(o/"screen-runs.json").write_text(json.dumps(rows,indent=2)+"\n");print(rows[-1],flush=True)
 if q.returncode:raise SystemExit(q.returncode)
f={name:json.loads((o/(name+".json")).read_text())["payload"]["frames"] for name in ("baseline","null","probe")};keys=("q","v","actor_observation","accepted_actions","body_states","reward","done","termination_reason","outcomes");parity={k:sum(x[k]!=y[k] for x,y in zip(f["baseline"],f["null"])) for k in keys};assert len(f["baseline"])==len(f["null"])==50
result={"baseline_null_differing_frames":parity,"probe_first_observation_equal":f["baseline"][0]["actor_observation"]==f["probe"][0]["actor_observation"],"probe_first_q_equal":f["baseline"][0]["q"]==f["probe"][0]["q"],"probe_first_v_equal":f["baseline"][0]["v"]==f["probe"][0]["v"]};(o/"screen-parity.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result,indent=2),flush=True)
if any(parity.values()):raise SystemExit("null differs from baseline")
