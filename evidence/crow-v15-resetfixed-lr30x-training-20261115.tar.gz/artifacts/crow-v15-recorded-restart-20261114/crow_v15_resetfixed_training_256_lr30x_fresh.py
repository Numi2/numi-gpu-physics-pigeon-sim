from pathlib import Path
import json,os,subprocess,hashlib,time
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';o=a/'v15-resetfixed-training-20370113-horizon256-lr30x-fresh';o.mkdir(exist_ok=False);cmd=json.loads((a/'neural-arrival-phase-history-continuation/update-04/command.json').read_text());cmd[0]=str(b/'v15-checkpoint-trainer-prototype/metalrobo_task_train')
def put(k,v):cmd[cmd.index(k)+1]=str(v)
for k,v in [('--envs',1),('--steps',256),('--seed',20370113),('--learner-seed',20370113),('--minibatch-size',256),('--policy-pack',b/'neural-arrival-phase-history-continuation-update-04.policypack'),('--learner-state',b/'neural-arrival-phase-history-continuation-update-04.safetensors'),('--native-library',b/'v15-checkpoint-effort-prototype/libmetalrobo.dylib'),('--metallib',b/'neural-arrival-reset-target-fixed-training.metallib'),('--updated-policy-pack',b/'v15-resetfixed-training-20370113-horizon256-lr30x-fresh.policypack'),('--rollout-pack',b/'v15-resetfixed-training-20370113-horizon256-lr30x-fresh.rollout'),('--output-learner-state',b/'v15-resetfixed-training-20370113-horizon256-lr30x-fresh.safetensors')]:put(k,v)
put("--learning-rate",0.0009)
i=cmd.index("--learner-state");del cmd[i:i+2]
env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/'v15-checkpoint-effort-prototype'),CROW_EXPERIMENT_GAIT_SMOOTH='1',CROW_RESEARCH_INITIAL_CHECKPOINT=str(a/'v15-resetfixed-training-checkpoint-source-20370113-49/life.chk'),CROW_RESEARCH_SOURCE_POLICY=str(b/'neural-arrival-phase-history-continuation-update-04.policypack.deployment.policypack'));env.pop('CROW_RECORDED_STATE_RESTART',None)
(o/'command.json').write_text(json.dumps(cmd,indent=2)+'\n');(o/'environment.json').write_text(json.dumps({k:env[k] for k in ('DYLD_LIBRARY_PATH','CROW_EXPERIMENT_GAIT_SMOOTH','CROW_RESEARCH_INITIAL_CHECKPOINT','CROW_RESEARCH_SOURCE_POLICY')},indent=2)+'\n');inputs=[cmd[0],cmd[cmd.index('--native-library')+1],cmd[cmd.index('--metallib')+1],cmd[cmd.index('--policy-pack')+1],cmd[cmd.index('--learner-state')+1],env['CROW_RESEARCH_INITIAL_CHECKPOINT'],env['CROW_RESEARCH_SOURCE_POLICY']];(o/'inputs.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in inputs},indent=2)+'\n');start=time.time()
with (o/'stdout').open('w') as so,(o/'stderr').open('w') as se:q=subprocess.run(cmd,cwd=r,env=env,stdout=so,stderr=se)
files={}
for suffix in ('policypack','policypack.deployment.policypack','rollout','safetensors'):
 p=b/('v15-resetfixed-training-20370113-horizon256-lr30x-fresh.'+suffix)
 if p.exists():files[str(p)]={'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(o/'result.json').write_text(json.dumps({'exit_code':q.returncode,'elapsed_seconds':time.time()-start,'files':files},indent=2)+'\n');print((o/'result.json').read_text());raise SystemExit(q.returncode)
