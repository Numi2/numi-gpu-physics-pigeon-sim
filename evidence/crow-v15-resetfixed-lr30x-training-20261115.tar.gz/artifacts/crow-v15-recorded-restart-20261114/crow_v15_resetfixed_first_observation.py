from pathlib import Path
import json,numpy as np
from metalrobo.mlx_policy_learning import read_policy_rollout_pack
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";b=r/"build/crow-v15-recorded-restart-20261114"
p=read_policy_rollout_pack(b/"v15-resetfixed-training-20370113-horizon256.rollout",library_path=b/"v15-checkpoint-effort-prototype/libmetalrobo.dylib")
x=np.asarray(p.actor_observations).reshape(-1,828)[0];y=np.asarray(json.loads((a/"v15-resetfixed-trained-evaluation-20370113-250/baseline.json").read_text())["payload"]["frames"][0]["actor_observation"],dtype=x.dtype)
report={"identical":bool(np.array_equal(x,y)),"max_abs_difference":float(np.max(np.abs(x-y))),"scope":"first rollout observation versus resumed deterministic evaluation at identical training checkpoint"}
(a/"v15-resetfixed-training-20370113-horizon256/first-observation-check.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report))
