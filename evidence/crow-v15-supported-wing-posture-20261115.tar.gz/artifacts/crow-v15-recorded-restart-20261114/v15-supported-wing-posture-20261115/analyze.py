from pathlib import Path
import json,hashlib,sys
a=Path('/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114');o=a/'v15-supported-wing-posture-eval-20261115';base=a/'v15-leg-posture-minus075-long-20261115/20370113-hip_negative-1500';result={}
def load_targets(p):
 out={}
 with p.open() as f:
  for line in f:
   if line.startswith('CROW_DRIVE_TARGET '):
    x=line.split();out[int(x[1])]=[float(v) for v in x[2:]]
 return out
baseline=json.loads(base.with_suffix('.json').read_text())['payload']['frames'];bt=load_targets(base.with_suffix('.stderr'))
for variant in (sys.argv[1:] or ('lower04','lower08')):
 stem=o/('20370113-'+variant+'-500');frames=json.loads(stem.with_suffix('.json').read_text())['payload']['frames'];tar=load_targets(stem.with_suffix('.stderr'));end=next((i+1 for i,f in enumerate(frames) if f['done']),len(frames));valid=frames[:end];dif=next((i for i in sorted(tar) if tar[i]!=bt[i]),None);steps={}
 with stem.with_suffix('.stderr').open() as f:
  for line in f:
   x=line.split()
   if not x or x[0]!='CROW_SCENE_CONTACT':continue
   t=int(x[1]);A=int(x[4]);B=int(x[5])
   if t>end or not ((A<35 and B==40) or (B<35 and A==40)):continue
   bird=A if B==40 else B;sign=-1 if B==40 else 1;side=0 if bird==11 or 19<=bird<=26 else 1 if bird==15 or 27<=bird<=34 else -1
   if side<0:continue
   n,j1,j2=map(float,x[6:9]);nx,ny,nz,tx,ty,tz=map(float,x[13:19]);vz=nx*ty-ny*tx;up=sign*(nz*n+tz*j1+vz*j2);s=steps.setdefault(t,[[0.,0.,0.,0.] for _ in range(2)])[side];s[0]+=n;s[1]+=up
   if 19<=bird<=24 or 27<=bird<=32:s[2]+=sign*nx*n
   if 25<=bird<=26 or 33<=bird<=34:s[3]+=sign*nx*n
 both=up=opposed=0
 for t in range(1,end+1):
  v=steps.get(t,[[0.,0.,0.,0.] for _ in range(2)]);both+=all(z[0]>1e-7 for z in v);up+=all(z[1]>1e-7 for z in v);opposed+=all(z[2]*z[3]<-1e-14 for z in v)
 result[variant]={'first_done':end if frames[end-1]['done'] else None,'frames_before_termination_inclusive':end,'peak_tilt':max(f['tilt'] for f in valid),'final_flap_q':valid[-1]['q'][9:11],'minimum_flap_q':[min(f['q'][i] for f in valid) for i in (9,10)],'initial_observation_equal':frames[0]['actor_observation']==baseline[0]['actor_observation'],'first_target_difference':dif,'exact_q_v_parity_before_difference':all(frames[i]['q']==baseline[i]['q'] and frames[i]['v']==baseline[i]['v'] for i in range(dif-1)) if dif else None,'first_target_delta':{str(i):round(tar[dif][i]-bt[dif][i],9) for i in range(len(tar[dif])) if abs(tar[dif][i]-bt[dif][i])>1e-7} if dif else {},'bilateral_branch_contact_steps':both,'bilateral_branch_net_upward_impulse_steps':up,'bilateral_opposed_toe_normal_proxy_steps':opposed}
result['method']='First episode only. Per control step, sum 16 substeps of branch body 40 impulses; feet 11/15 and toe IDs 19..26/27..34. Opposed toe normals are a geometric proxy, not validated grip. q[9:11] are actual physical flap joints; geometric feather folding is not simulated.'
(o/('analysis-'+'-'.join(sys.argv[1:])+'.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
