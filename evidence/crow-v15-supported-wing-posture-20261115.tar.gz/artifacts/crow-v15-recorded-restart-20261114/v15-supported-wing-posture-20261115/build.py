from pathlib import Path
import json, subprocess, hashlib
r=Path('/Users/n/Developer/numi-crow-rl-20261107'); a=r/'artifacts/crow-v15-recorded-restart-20261114'; o=a/'v15-supported-wing-posture-20261115'; b=r/'build/crow-v15-recorded-restart-20261114/v15-supported-wing-posture-20261115'; b.mkdir(exist_ok=False)
source=a/'v15-wholebody-v3/neural.metal'; text=source.read_text(); record=json.loads((a/'v15-wholebody-v3/build.json').read_text())['neural']; needle='        const float target = clamp(\n            targetCandidate,\n            binding.parameters.y,'; assert text.count(needle)==1
results={}
for label,offset in [('lower04',0.4),('lower08',0.8)]:
    intervention=f'''        // Supported physical wing-lowering identification, not a learned policy.
        if (fixedFlightController && state.navigation.z>=5.0f && state.episode.x>=2500u && action<=1u) {{
            const bool bilateral=dispatch.counts.w==40u && (state.status.w & (1u<<20))!=0u && (state.status.w & (1u<<21))!=0u;
            const float ramp=smoothstep(2500.0f,2550.0f,float(state.episode.x));
            const float quiet=1.0f-smoothstep(0.22f,0.32f,abs(state.threatGeometry.z));
            targetCandidate-=bilateral ? {offset:.1f}f*ramp*quiet : 0.0f;
        }}
'''
    src=o/(label+'.metal'); src.write_text(text.replace(needle,intervention+needle)); air=b/(label+'.air'); lib=b/(label+'.metallib'); cc=record['compile']['argv'].copy(); cc[cc.index('-c')+1]=str(src); cc[cc.index('-o')+1]=str(air); ld=record['link']['argv'].copy(); ld[ld.index('-o')+1]=str(lib); ld=[str(air) if x.endswith('/v15-wholebody-v3/neural.air') else x for x in ld]; assert str(air) in ld
    results[label]={}
    for kind,cmd in [('compile',cc),('link',ld)]:
        p=subprocess.run(cmd,cwd=r,text=True,capture_output=True); results[label][kind]={'argv':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}; (o/'build.json').write_text(json.dumps(results,indent=2)+'\n'); print(label,kind,p.returncode,flush=True)
        if p.returncode: raise SystemExit(p.returncode)
    results[label]['sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source,src,air,lib)}
(o/'build.json').write_text(json.dumps(results,indent=2)+'\n')
