from pathlib import Path
import json,numpy as np
p=Path("/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114");o=p/"v15-rear-toe-authority-20261115"
def read(q):
 d={}
 with q.open() as f:
  for s in f:
   x=s.split()
   if x and x[0]=="CROW_DRIVE_TARGET":d[int(x[1])]=np.asarray(list(map(float,x[3:])))[[28,29,36,37]]
 return d
z=read(p/"v15-pitch-authority-20261115/zero.stderr");out={}
for label in ("rear_positive","rear_negative"):
 vals=read(o/(label+".stderr"));end=207 if label=="rear_positive" else 134;delta=np.asarray([vals[t]-z[t] for t in range(1,end+1)]);out[label]={"first_targets":vals[1].tolist(),"zero_first_targets":z[1].tolist(),"max_absolute_target_difference":np.max(np.abs(delta),axis=0).tolist(),"first_target_difference":delta[0].tolist(),"intervals_with_each_target_delta_gt_0_001":np.sum(np.abs(delta)>0.001,axis=0).tolist(),"first_episode_intervals":end}
(o/"target-analysis.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2))
