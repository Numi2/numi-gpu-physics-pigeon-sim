from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";b=r/"build/crow-v15-recorded-restart-20261114";o=a/"v15-leg-posture-minus075-easy-20261115";o.mkdir(exist_ok=False);rows=[];results={}
for seed,split in ((20370127,50),):
 results[str(seed)]={}
 source=a/f"v15-resetfixed-checkpoint-roundtrip-{seed}-{split}-100";ck=a/"v15-wholebody-v3"/("neural.chk" if split==49 else "easy-neural.chk")
 for rate in ("control","hip_negative"):
  tag=f"{seed}-{rate}-400";policy=(a/"v15-pitch-authority-20261115/zero.policypack" if rate=="control" else a/"v15-leg-posture-magnitude-20261115/hip_minus075.policypack");c=json.loads((source/"resume.command.json").read_text());c[0]=str(b/"v15-checkpoint-fork-prototype/metalrobo_task_rollout")
  for k,v in (("--steps",400),("--state-trace",o/(tag+".tsv")),("--crow-replay-pack",o/(tag+".json")),("--metallib",b/"v15-wholebody-v3/neural.metallib"),("--resume-life-checkpoint",ck)):c[c.index(k)+1]=str(v)
  env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/"v15-checkpoint-effort-prototype"),CROW_EXPERIMENT_GAIT_SMOOTH="1",CROW_CHECKPOINT_FORK_POLICY=str(policy),CROW_SUBSTEP_TRACE="1");env.pop("CROW_RECORDED_STATE_RESTART",None)
  (o/(tag+".command.json")).write_text(json.dumps(c,indent=2)+"\n");(o/(tag+".inputs.json")).write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (policy,ck,b/"v15-wholebody-v3/neural.metallib")},indent=2)+"\n");t=time.time()
  with (o/(tag+".stdout")).open("w") as so,(o/(tag+".stderr")).open("w") as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
  rows.append({"name":tag,"exit_code":q.returncode,"elapsed":time.time()-t});(o/"runs.json").write_text(json.dumps(rows,indent=2)+"\n");print(rows[-1],flush=True)
  if q.returncode:raise SystemExit(q.returncode)
  fs=json.loads((o/(tag+".json")).read_text())["payload"]["frames"];done=next((i+1 for i,x in enumerate(fs) if x["done"]),None);valid=fs[:done] if done else fs;results[str(seed)][rate]={"first_done_relative":done,"first_done_absolute":split+done if done else None,"first_250_max_tilt":max(x["tilt"] for x in valid[:250]),"frames":len(fs),"maximum_new_action_by_slot":[max(abs(x["accepted_actions"][j]) for x in valid) for j in range(8,18)]};(o/"summary.json").write_text(json.dumps(results,indent=2)+"\n")
print(json.dumps(results,indent=2),flush=True)
