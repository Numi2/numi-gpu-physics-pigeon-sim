from pathlib import Path
import json,math
p=Path("/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114/v15-leg-posture-minus075-easy-20261115");result={}
for label,stem in (("control","20370127-control-400"),("candidate","20370127-hip_negative-400")):
 frames=json.loads((p/(stem+".json")).read_text())["payload"]["frames"];end=next((i+1 for i,f in enumerate(frames) if f["done"]),len(frames));steps={}
 with (p/(stem+".stderr")).open() as f:
  for line in f:
   x=line.split()
   if not x or x[0]!="CROW_SCENE_CONTACT":continue
   t=int(x[1]);A=int(x[4]);B=int(x[5])
   if t>end or not ((A<35 and B==40) or (B<35 and A==40)):continue
   bird=A if B==40 else B;sign=-1 if B==40 else 1;side=0 if bird==11 or 19<=bird<=26 else 1 if bird==15 or 27<=bird<=34 else -1
   if side<0:continue
   n,j1,j2=map(float,x[6:9]);nx,ny,nz,tx,ty,tz=map(float,x[13:19]);vz=nx*ty-ny*tx;up=sign*(nz*n+tz*j1+vz*j2);s=steps.setdefault(t,[[0.,0.,0.,0.] for _ in range(2)])[side];s[0]+=n;s[1]+=up
   if (19<=bird<=24) or (27<=bird<=32):s[2]+=sign*nx*n
   if (25<=bird<=26) or (33<=bird<=34):s[3]+=sign*nx*n
 def longest(flags):
  best=run=0
  for flag in flags:run=run+1 if flag else 0;best=max(best,run)
  return best
 both=[];up=[];opposed=[]
 for t in range(1,end+1):
  v=steps.get(t,[[0.,0.,0.,0.] for _ in range(2)]);both.append(all(z[0]>1e-7 for z in v));up.append(all(z[1]>1e-7 for z in v));opposed.append(all(z[2]*z[3]<-1e-14 for z in v))
 result[label]={"valid_control_steps":end,"branch_both_feet_contact_steps":sum(both),"branch_both_feet_net_upward_impulse_steps":sum(up),"both_feet_opposing_front_rear_normal_x_steps":sum(opposed),"longest_contiguous_bilateral_contact_steps":longest(both),"longest_contiguous_bilateral_upward_steps":longest(up),"longest_contiguous_bilateral_opposing_normal_steps":longest(opposed)}
result["method"]="Per control interval, sum 16 substeps of scene body 40 contact impulses; body 40 is the fifth course object after ground and four obstacles. Feet are rigid-body IDs 11/15 and toe IDs 19..26/27..34. Opposed front/rear x-normal impulse is a geometric proxy, not validated grasp stability. Values after first done excluded."
(p/"contact-summary.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result,indent=2))
