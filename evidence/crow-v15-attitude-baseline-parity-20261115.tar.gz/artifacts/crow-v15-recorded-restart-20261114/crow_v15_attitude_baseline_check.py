from pathlib import Path
import json
r=Path("/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114");out={}
for seed in (20370113,20370127):
 p=r/f"v15-resetfixed-attitude-baseline-zero-evaluation-{seed}-250";x=json.loads((p/"baseline.json").read_text())["payload"]["frames"];y=json.loads((p/"candidate.json").read_text())["payload"]["frames"];fields=("q","v","actor_observation","accepted_actions","body_states","reward","done","termination_reason","outcomes");assert len(x)==len(y)==250;out[str(seed)]={k:sum(a[k]!=b[k] for a,b in zip(x,y)) for k in fields}
(r/"v15-resetfixed-attitude-baseline-zero-parity.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2));assert all(not n for row in out.values() for n in row.values())
