from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';o=a/'v15-com-signal-diagnostic-eval-20261115';o.mkdir(exist_ok=False);rows=[];source=a/'v15-resetfixed-checkpoint-roundtrip-20370113-49-100';policy=a/'v15-coupled-wing-hip-20261115/hip_minus090.policypack'
for variant in ('com_signal_diagnostic',):
 ck=a/'v15-com-signal-diagnostic-20261115'/(variant+'.chk');tag='20370113-'+variant+'-620';c=json.loads((source/'resume.command.json').read_text());c[0]=str(b/'v15-checkpoint-fork-prototype/metalrobo_task_rollout');lib=b/f'v15-com-signal-diagnostic-20261115/{variant}.metallib'
 for k,v in (('--steps',620),('--state-trace',o/(tag+'.tsv')),('--crow-replay-pack',o/(tag+'.json')),('--metallib',lib),('--resume-life-checkpoint',ck)):c[c.index(k)+1]=str(v)
 env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/'v15-checkpoint-effort-prototype'),CROW_EXPERIMENT_GAIT_SMOOTH='1',CROW_CHECKPOINT_FORK_POLICY=str(policy),CROW_SUBSTEP_TRACE='1');env.pop('CROW_RECORDED_STATE_RESTART',None);(o/(tag+'.command.json')).write_text(json.dumps(c,indent=2)+'\n');(o/(tag+'.inputs.json')).write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (policy,ck,lib)},indent=2)+'\n');t=time.time()
 with (o/(tag+'.stdout')).open('w') as so,(o/(tag+'.stderr')).open('w') as se:p=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 rows.append({'name':tag,'exit_code':p.returncode,'elapsed':time.time()-t});(o/'runs.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
