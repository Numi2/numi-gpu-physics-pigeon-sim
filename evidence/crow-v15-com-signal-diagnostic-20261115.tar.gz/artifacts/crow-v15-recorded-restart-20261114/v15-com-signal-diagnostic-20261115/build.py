from pathlib import Path
import json,subprocess,hashlib
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';o=a/'v15-com-signal-diagnostic-20261115';b=r/'build/crow-v15-recorded-restart-20261114/v15-com-signal-diagnostic-20261115';o.mkdir(exist_ok=False);b.mkdir(exist_ok=False)
source=a/'v15-com-contact-feedback-20261115/com_feedback_pos.metal';s=source.read_text()
block='''        // Bounded ideal-state COM/contact feedback after identical pulse.
        if (fixedFlightController && state.navigation.z>=5.0f && state.episode.x>=3010u && (action==7u || action==10u)) {
            targetCandidate+=1.0f*clamp(0.60f*state.airReturnTracking.x,-0.06f,0.06f);
        }
'''
assert s.count(block)==1;s=s.replace(block,'')
needle='''    MRTaskStateGPU state = taskStates[environment];
    state.airReturnTracking.x = mechanicalPower;'''
assert s.count(needle)==1;s=s.replace(needle,'''    MRTaskStateGPU state = taskStates[environment];
    // Diagnostics only: snapshot the signal after action application, before power overwrites it.
    if (state.episode.z==10u && state.episode.x>=3000u) state.airReturnTracking.z=state.airReturnTracking.x;
    state.airReturnTracking.x = mechanicalPower;''')
# In completion kernel, preserve the diagnostic snapshot before return bookkeeping.
pos=s.index('kernel void mr_locomotion_task_complete_history2(');start=s[:pos];tail=s[pos:];needle='    MRTaskStateGPU state = taskStates[environment];';assert tail.count(needle)==1;tail=tail.replace(needle,needle+'\n    const float diagnosticActionSeenSignal=state.airReturnTracking.z;')
needle='    // Research-only task-private accepted COM/contact signal; not a policy observation.';assert tail.count(needle)==1;tail=tail.replace(needle,'    float4 diagnosticValues=float4(0.0f);\n'+needle)
needle='''        state.airReturnTracking.x=(mass>0.0f && totalUp>1.0e-8f)
            ? clamp((comX/mass-weightedX/totalUp-0.0236f)+0.10f*velX/mass,-0.20f,0.20f) : 0.0f;''';assert tail.count(needle)==1;tail=tail.replace(needle,needle+'\n        diagnosticValues=float4(mass,totalUp,float(perch),state.airReturnTracking.x);')
needle='''    taskStates[environment] = state;

    const uint transitionIndex =''';assert tail.count(needle)==1;tail=tail.replace(needle,'''    // Diagnostic telemetry replaces reward only; never train on this run.
    if (state.episode.z==10u && state.episode.x>=3000u) {
        const uint phase=state.episode.x%5u;
        reward=phase==0u ? diagnosticValues.x : phase==1u ? diagnosticValues.y : phase==2u ? diagnosticValues.z : phase==3u ? diagnosticValues.w : diagnosticActionSeenSignal;
    }
    taskStates[environment] = state;

    const uint transitionIndex =''');s=start+tail
src=o/'com_signal_diagnostic.metal';src.write_text(s);air=b/'com_signal_diagnostic.air';lib=b/'com_signal_diagnostic.metallib';record=json.loads((a/'v15-wholebody-v3/build.json').read_text())['neural'];cc=record['compile']['argv'].copy();cc[cc.index('-c')+1]=str(src);cc[cc.index('-o')+1]=str(air);ld=record['link']['argv'].copy();ld[ld.index('-o')+1]=str(lib);ld=[str(air) if x.endswith('/v15-wholebody-v3/neural.air') else x for x in ld];assert str(air) in ld;out={}
for kind,cmd in [('compile',cc),('link',ld)]:
 p=subprocess.run(cmd,cwd=r,text=True,capture_output=True);out[kind]={'argv':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr};(o/'build.json').write_text(json.dumps(out,indent=2)+'\n');print(kind,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
out['sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source,src,air,lib)};(o/'build.json').write_text(json.dumps(out,indent=2)+'\n')
