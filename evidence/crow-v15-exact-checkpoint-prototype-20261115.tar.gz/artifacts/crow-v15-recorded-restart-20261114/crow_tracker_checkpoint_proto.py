from pathlib import Path
import json,shlex,subprocess,hashlib
root=Path('/Users/n/Developer/numi-crow-rl-20261107');a=root/'artifacts/crow-v15-recorded-restart-20261114';b=root/'build/crow-v15-recorded-restart-20261114';overlay=b/'v15-checkpoint-prototype/include/metalrobo';overlay.mkdir(parents=True,exist_ok=True)
header=(root/'include/metalrobo/MetalHybridRenderer.hpp').read_text();marker='    [[nodiscard]] MetalHybridRendererDiagnostics reset();\n\nprivate:';assert header.count(marker)==1
header=header.replace(marker,'''    [[nodiscard]] MetalHybridRendererDiagnostics reset();

    // Experimental: caller must establish a quiescent world and identify the exact visual scene.
    [[nodiscard]] std::vector<std::byte> checkpointTracker(std::uint64_t identity) const;
    void restoreTracker(std::span<const std::byte> bytes, std::uint64_t identity);

private:''');(overlay/'MetalHybridRenderer.hpp').write_text(header)
src=(root/'src/metal/MetalHybridRenderer.mm').read_text();src=src.replace('#include "metalrobo/MetalHybridRenderer.hpp"','#include "metalrobo/MetalHybridRenderer.hpp"\n#include "metalrobo/detail/Checkpoint.hpp"',1)
marker='bool MetalHybridObjectTracker::encodeObservation(';assert src.count(marker)==1
code=r'''
std::vector<std::byte> MetalHybridObjectTracker::checkpointTracker(std::uint64_t identity) const {
    using namespace checkpoint;
    require(state_ && state_->compiled && state_->renderer && state_->worlds && state_->device,
        "Tracker checkpoint requires compiled visual state");
    require(state_->directWinnerMaskedDepth && state_->config.bindings.empty(),
        "Tracker checkpoint prototype supports direct masked-depth only");
    auto& renderer=*state_->renderer->state_; const std::lock_guard lock(renderer.mutex);
    const std::array<id<MTLBuffer>,7> buffers{{state_->history,state_->maskedDepthHistory,
        renderer.buffers.depth,renderer.buffers.identities,renderer.buffers.validity,
        renderer.buffers.cameraStates,renderer.buffers.meshWinners}};
    require(buffers[0] && buffers[1] && buffers[5] && buffers[6],"Tracker checkpoint missing buffers");
    std::size_t total=0; for (id<MTLBuffer> b:buffers) if(b) {require(b.length<=SIZE_MAX-total,"Tracker checkpoint size overflow");total+=b.length;}
    id<MTLBuffer> staging=[state_->device newBufferWithLength:std::max<std::size_t>(total,1) options:MTLResourceStorageModeShared];
    id<MTLCommandBuffer> command=[renderer.queue commandBuffer]; id<MTLBlitCommandEncoder> blit=[command blitCommandEncoder];
    require(staging && command && blit,"Tracker checkpoint staging failure"); std::size_t offset=0;
    for(id<MTLBuffer> b:buffers) if(b) {[blit copyFromBuffer:b sourceOffset:0 toBuffer:staging destinationOffset:offset size:b.length];offset+=b.length;}
    [blit endEncoding];[command commit];[command waitUntilCompleted];
    require(command.status==MTLCommandBufferStatusCompleted,"Tracker checkpoint GPU readback failure");
    Bytes payload;append(payload,state_->observationSequence);append(payload,state_->lastSensorSequence);
    append(payload,state_->maskedDepthRenderUniforms);offset=0;
    for(id<MTLBuffer> b:buffers) {const std::size_t size=b ? b.length : 0;appendBlob(payload,{static_cast<const std::byte*>(staging.contents)+offset,size});offset+=size;}
    return seal({'C','R','W','T','R','K','0','1'},identity,payload);
}
void MetalHybridObjectTracker::restoreTracker(std::span<const std::byte> bytes,std::uint64_t identity) {
    using namespace checkpoint;
    require(state_ && state_->compiled && state_->renderer && state_->worlds && state_->device,
        "Tracker restore requires compiled visual state");
    require(state_->directWinnerMaskedDepth && state_->config.bindings.empty(),
        "Tracker restore prototype supports direct masked-depth only");
    auto& renderer=*state_->renderer->state_;const std::lock_guard lock(renderer.mutex);
    const std::array<id<MTLBuffer>,7> buffers{{state_->history,state_->maskedDepthHistory,
        renderer.buffers.depth,renderer.buffers.identities,renderer.buffers.validity,
        renderer.buffers.cameraStates,renderer.buffers.meshWinners}};
    require(buffers[0] && buffers[1] && buffers[5] && buffers[6],"Tracker restore missing buffers");
    Reader r{open(bytes,{'C','R','W','T','R','K','0','1'},identity)};
    const auto observation=r.get<std::uint64_t>(),sensor=r.get<std::uint64_t>();
    const auto uniforms=r.get<MRHybridRenderUniformsGPU>();
    require(sensor==std::numeric_limits<std::uint64_t>::max() || observation>0,"Invalid tracker sensor phase");
    std::array<std::span<const std::byte>,7> sections{};std::size_t total=0;
    for(std::size_t i=0;i<buffers.size();++i) {sections[i]=r.blob();const auto expected=buffers[i] ? buffers[i].length : 0;
        require(sections[i].size()==expected && expected<=SIZE_MAX-total,"Tracker checkpoint buffer layout mismatch");total+=expected;}
    r.end();
    id<MTLBuffer> staging=[state_->device newBufferWithLength:std::max<std::size_t>(total,1) options:MTLResourceStorageModeShared];
    id<MTLCommandBuffer> command=[renderer.queue commandBuffer];id<MTLBlitCommandEncoder> blit=[command blitCommandEncoder];
    require(staging && command && blit,"Tracker restore staging failure");std::size_t offset=0;
    for(std::size_t i=0;i<buffers.size();++i) {const auto n=sections[i].size();if(n) {std::memcpy(static_cast<std::byte*>(staging.contents)+offset,sections[i].data(),n);
        [blit copyFromBuffer:staging sourceOffset:offset toBuffer:buffers[i] destinationOffset:0 size:n];}offset+=n;}
    [blit endEncoding];[command commit];[command waitUntilCompleted];
    require(command.status==MTLCommandBufferStatusCompleted,"Tracker restore GPU upload failure");
    state_->observationSequence=observation;state_->lastSensorSequence=sensor;state_->maskedDepthRenderUniforms=uniforms;
}

'''
src=src.replace(marker,code+marker);p=a/'MetalHybridRenderer-v15-checkpoint-prototype.mm';p.write_text(src)
compile_db=json.loads((root/'build/compile_commands.json').read_text());entry=next(v for v in compile_db if v['file'].endswith('MetalHybridRenderer.mm'));cmd=shlex.split(entry['command']);cmd.insert(1,'-I'+str(overlay.parent));cmd[cmd.index('-o')+1]=str(b/'v15-checkpoint-prototype/MetalHybridRenderer.o');cmd[cmd.index('-c')+1]=str(p)
res=subprocess.run(cmd,cwd=root/'build',text=True,capture_output=True);record={'compile':cmd,'exit_code':res.returncode,'stdout':res.stdout,'stderr':res.stderr,'sources':{str(p):hashlib.sha256(p.read_bytes()).hexdigest(),str(overlay/'MetalHybridRenderer.hpp'):hashlib.sha256((overlay/'MetalHybridRenderer.hpp').read_bytes()).hexdigest()},'scope':'isolated tracker checkpoint prototype, not integrated or verified'};(a/'v15-tracker-checkpoint-prototype-build.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'exit_code':res.returncode,'stderr':res.stderr[-8000:]},indent=2));raise SystemExit(res.returncode)
