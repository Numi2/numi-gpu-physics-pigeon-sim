from pathlib import Path
import json,os,subprocess,hashlib,time
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';p=b/'v15-checkpoint-prototype';out=a/'v15-checkpoint-prototype-trace-50';out.mkdir(exist_ok=False)
cmd=json.loads((a/'round-position-aligned-valid-toe-400/command.json').read_text());i=cmd.index('--base-policy-pack');del cmd[i:i+2];cmd[0]=str(p/'metalrobo_task_rollout')
for k,v in [('--birdflow-journey-variant','v15-hierarchical-navigation'),('--steps','100'),('--envs','1'),('--seed','20370127'),('--policy-pack',str(b/'neural-arrival-phase-history-continuation-update-04.policypack.deployment.policypack')),('--metallib',str(b/'neural-arrival-phase-history-control-eval.metallib'))]:cmd[cmd.index(k)+1]=v
env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/'v15-checkpoint-trace-prototype'),CROW_EXPERIMENT_GAIT_SMOOTH='1',CROW_SUBSTEP_TRACE='1');env.pop('CROW_RECORDED_STATE_RESTART',None)
rows=[]
for name,steps,option in [('continuous',51,'--save-life-checkpoint'),('prefix',50,'--save-life-checkpoint'),('resume',1,'--resume-life-checkpoint')]:
 c=cmd.copy()
 for k,v in [('--steps',steps),('--state-trace',out/(name+'.tsv')),('--crow-replay-pack',out/(name+'.json'))]:c[c.index(k)+1]=str(v)
 if option:c.extend([option,str(out/('continuous.chk' if name=='continuous' else 'life.chk'))])
 (out/(name+'.command.json')).write_text(json.dumps(c,indent=2)+'\n')
 started=time.time()
 with (out/(name+'.stdout')).open('w') as so,(out/(name+'.stderr')).open('w') as se: result=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 rows.append({'name':name,'exit_code':result.returncode,'seconds':time.time()-started});(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
 if result.returncode:raise SystemExit(result.returncode)
