from pathlib import Path
import json,os,subprocess,hashlib
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';o=a/'v15-checkpoint-effort-rejection-probe';o.mkdir(exist_ok=False);source=a/'v15-checkpoint-effort-roundtrip-50';original=source/'life.chk';data=original.read_bytes();(o/'truncated.chk').write_bytes(data[:-1]);changed=bytearray(data);changed[len(data)//2]^=1;(o/'modified.chk').write_bytes(changed)
cmd=json.loads((source/'resume.command.json').read_text());env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/'v15-checkpoint-effort-prototype'),CROW_EXPERIMENT_GAIT_SMOOTH='1');env.pop('CROW_RECORDED_STATE_RESTART',None)
# An alternate camera keeps scene dimensions and sensor rate but changes the FOV.
configPath=Path(cmd[cmd.index('--visual-observation-config')+1]);config=json.loads(configPath.read_text())
for pack in config['packs']:pack['path']=str((configPath.parent/pack['path']).resolve())
config['camera']['vertical_field_of_view_degrees']=50.0;camera=o/'changed-camera.json';camera.write_text(json.dumps(config,indent=2)+'\n')
rows=[]
for name in ('modified','truncated','wrong_seed','changed_camera'):
 c=cmd.copy();c[c.index('--steps')+1]='1';c[c.index('--state-trace')+1]=str(o/(name+'.tsv'));c[c.index('--crow-replay-pack')+1]=str(o/(name+'.json'))
 c[c.index('--resume-life-checkpoint')+1]=str(o/(name+'.chk') if name in ('modified','truncated') else original)
 if name=='wrong_seed':c[c.index('--seed')+1]='20370128'
 if name=='changed_camera':c[c.index('--visual-observation-config')+1]=str(camera)
 (o/(name+'.command.json')).write_text(json.dumps(c,indent=2)+'\n')
 with (o/(name+'.stdout')).open('w') as so,(o/(name+'.stderr')).open('w') as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 rows.append({'name':name,'exit_code':q.returncode,'unexpectedly_accepted':q.returncode==0,'stderr_tail':(o/(name+'.stderr')).read_text()[-1200:]});print(name,q.returncode,flush=True)
(o/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
