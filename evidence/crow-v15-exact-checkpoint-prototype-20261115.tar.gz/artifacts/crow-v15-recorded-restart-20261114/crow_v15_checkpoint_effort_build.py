from pathlib import Path
import json,subprocess
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';p=b/'v15-checkpoint-prototype';t=b/'v15-checkpoint-effort-prototype';t.mkdir(exist_ok=False)
s=(a/'MetalWorld-v15-checkpoint-trace-prototype.mm').read_text();key='bool privatePersistentBuffer(const std::size_t index) {\n    switch (index) {\n';assert s.count(key)==1;s=s.replace(key,key+'    case kEffortTrajectory:\n');src=a/'MetalWorld-v15-checkpoint-effort-prototype.mm';src.write_text(s)
rec=json.loads((a/'v15-checkpoint-prototype-host-build.json').read_text());c=rec['world_compile']['command'];c[c.index('-o')+1]=str(t/'MetalWorld.o');c[c.index('-c')+1]=str(src);l=rec['link']['command'];l[l.index('-o')+1]=str(t/'libmetalrobo.dylib');l=[str(t/'MetalWorld.o') if x==str(p/'MetalWorld.o') else x for x in l]
records={}
for label,cmd in [('compile',c),('link',l)]:
 q=subprocess.run(cmd,cwd=r/'build',text=True,capture_output=True);records[label]={'command':cmd,'exit_code':q.returncode,'stderr':q.stderr};print(label,q.returncode,q.stderr[-2000:],flush=True)
 (a/'v15-checkpoint-effort-prototype-build.json').write_text(json.dumps(records,indent=2)+'\n')
 if q.returncode:raise SystemExit(q.returncode)
