from pathlib import Path
import json,subprocess,hashlib
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";o=a/"v15-wholebody-v2-training";b=r/"build/crow-v15-recorded-restart-20261114/v15-wholebody-v2-training";b.mkdir(exist_ok=False)
record=json.loads((a/"neural-arrival-reset-target-fixed-build.json").read_text());original=(a/"neural-arrival-reset-target-fixed-training.metal").read_text()
needle="""        const float target = clamp(
            targetCandidate,
            binding.parameters.y,""";assert original.count(needle)==1
rollneedle="""        effortTrajectory[pass.controlStep*worldDispatch.effortStepStride + environment*worldDispatch.effortEnvironmentStride + 38u]=.22f*shift;
        effortTrajectory[pass.controlStep*worldDispatch.effortStepStride + environment*worldDispatch.effortEnvironmentStride + 39u]=.22f*shift;""";assert original.count(rollneedle)==1
results={}
for kind in ("null","probe","neural"):
 signal="0.0f" if kind=="null" else "0.5f" if kind=="probe" else "clamp(actionStream[actionBase+slot],-1.0f,1.0f)"
 add="""        // Research-only whole-body physical joint target residual; bounded by existing joint limits below.
        if (fixedFlightController && state.navigation.z>=5.0f && state.episode.x>=2450u && (action<=6u || action==8u || action==11u || action==15u || action==16u)) {
            const uint slot=action<=1u ? 8u+action : action<=3u ? 10u : action<=5u ? 11u : action==6u ? 12u : action==8u ? 13u : action==11u ? 14u : action;
            const float scale=(action<=1u || action==6u) ? .10f : .08f;
            targetCandidate+=scale*(SIGNAL);
        }
""".replace("SIGNAL",signal)
 rollsignal=signal.replace("actionBase+slot","actionBase+17u")
 roll="""        const bool wbPerch=state.navigation.z>=5.0f && state.episode.x>=2450u;
        const float wbRoll=wbPerch ? .08f*(SIGNAL) : 0.0f;
        effortTrajectory[pass.controlStep*worldDispatch.effortStepStride + environment*worldDispatch.effortEnvironmentStride + 38u]=clamp(.22f*shift+wbRoll,-.35f,.35f);
        effortTrajectory[pass.controlStep*worldDispatch.effortStepStride + environment*worldDispatch.effortEnvironmentStride + 39u]=clamp(.22f*shift-wbRoll,-.35f,.35f);""".replace("SIGNAL",rollsignal)
 text=original.replace(needle,add+needle).replace(rollneedle,roll);src=o/(kind+".metal");src.write_text(text);air=b/(kind+".air");lib=b/(kind+".metallib");compile=record["training"]["compile"]["command"].copy();compile[compile.index("-c")+1]=str(src);compile[compile.index("-o")+1]=str(air);link=record["training"]["link"]["command"].copy();link[link.index("-o")+1]=str(lib);link=[str(air) if x.endswith("neural-arrival-reset-target-fixed-training.air") else x for x in link];results[kind]={}
 for name,cmd in (("compile",compile),("link",link)):
  q=subprocess.run(cmd,cwd=r,text=True,capture_output=True);results[kind][name]={"argv":cmd,"exit":q.returncode,"stdout":q.stdout,"stderr":q.stderr};(o/"build.json").write_text(json.dumps(results,indent=2)+"\n");print(kind,name,q.returncode,flush=True)
  if q.returncode:raise SystemExit(q.returncode)
 results[kind]["sha256"]={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (src,air,lib)}
(o/"build.json").write_text(json.dumps(results,indent=2)+"\n")
