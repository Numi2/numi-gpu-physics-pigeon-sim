from pathlib import Path
import mlx.core as mx,numpy as np,json,hashlib,sys
from metalrobo.mlx_policy_learning import read_policy_pack
r=Path("/Users/n/Developer/numi-crow-rl-20261107");b=r/"build/crow-v15-recorded-restart-20261114";n=sys.argv[1];lib=b/"toe-sensing-experiment-host/libmetalrobo.dylib";x=read_policy_pack(b/"v15-resetfixed-attitude-baseline-zero-stochastic.policypack",library_path=lib);y=read_policy_pack(b/(n+".policypack"),library_path=lib);checks={"mean":np.array_equal(x.effective_observation_mean,y.effective_observation_mean),"scale":np.array_equal(x.effective_observation_inverse_standard_deviation,y.effective_observation_inverse_standard_deviation),"logstd":np.array_equal(x.action_log_standard_deviation,y.action_log_standard_deviation),"contract":all(getattr(x,k)==getattr(y,k) for k in ("world_fingerprint","task_fingerprint","observation_fingerprint","action_fingerprint"))}
for i,(u,v) in enumerate(zip(x.layers,y.layers)):
 mask=np.zeros(u.weights.shape,bool)
 if i==len(x.layers)-1:mask[8:18,-42:]=True
 checks[f"layer_{i}_protected"]=np.array_equal(u.weights[~mask],v.weights[~mask]);checks[f"layer_{i}_bias"]=np.array_equal(u.bias,v.bias)
p=b/(n+".safetensors");d=mx.load(str(p));moments={}
for k,v in d.items():
 if not (k.startswith("optimizer.actor.") or k.startswith("optimizer.log_standard_deviation.")):continue
 arr=np.asarray(v);mask=np.zeros(arr.shape,bool)
 if "actor.layers.6.weight." in k:mask[8:18,-42:]=True
 moments[k]=int(np.count_nonzero(arr[~mask]))
assert moments;out={"optimizer_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"actor_checks":{k:bool(v) for k,v in checks.items()},"protected_nonzero_by_moment":moments};print(json.dumps(out,indent=2));assert all(checks.values()) and not any(moments.values())
