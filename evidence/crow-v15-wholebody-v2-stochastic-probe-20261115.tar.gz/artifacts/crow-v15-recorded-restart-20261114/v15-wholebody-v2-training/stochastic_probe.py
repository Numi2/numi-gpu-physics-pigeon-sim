from pathlib import Path
import json,os,subprocess,time
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";o=a/"v15-wholebody-v2-training";b=r/"build/crow-v15-recorded-restart-20261114";source=a/"v15-resetfixed-checkpoint-roundtrip-20370113-150-200";cmd=json.loads((source/"resume.command.json").read_text());cmd[0]=str(b/"v15-checkpoint-fork-prototype/metalrobo_task_rollout");cmd[cmd.index("--metallib")+1]=str(b/"v15-wholebody-v2-training/neural.metallib");cmd[cmd.index("--resume-life-checkpoint")+1]=str(o/"checkpoint-20370113-150/life.chk");cmd[cmd.index("--steps")+1]="5";rows=[]
for name in ("reference","stochastic"):
 c=cmd.copy();c[c.index("--state-trace")+1]=str(o/(name+"-probe.tsv"));c[c.index("--crow-replay-pack")+1]=str(o/(name+"-probe.json"));env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/"v15-checkpoint-effort-prototype"),CROW_EXPERIMENT_GAIT_SMOOTH="1",CROW_SUBSTEP_TRACE="1");env.pop("CROW_RECORDED_STATE_RESTART",None);env.pop("CROW_CHECKPOINT_FORK_POLICY",None)
 if name=="stochastic":env["CROW_CHECKPOINT_FORK_POLICY"]=str(b/"v15-resetfixed-attitude-baseline-zero-stochastic.policypack")
 (o/(name+"-probe.command.json")).write_text(json.dumps({"argv":c,"fork":env.get("CROW_CHECKPOINT_FORK_POLICY")},indent=2)+"\n");t=time.time()
 with (o/(name+"-probe.stdout")).open("w") as so,(o/(name+"-probe.stderr")).open("w") as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 rows.append({"name":name,"exit_code":q.returncode,"elapsed":time.time()-t});(o/"stochastic-probe-runs.json").write_text(json.dumps(rows,indent=2)+"\n");print(rows[-1],flush=True)
 if q.returncode:raise SystemExit(q.returncode)
f=json.loads((o/"stochastic-probe.json").read_text())["payload"]["frames"];ref=json.loads((o/"reference-probe.json").read_text())["payload"]["frames"]
def targets(path):
 for line in path.read_text().splitlines():
  p=line.split()
  if p and p[0]=="CROW_DRIVE_TARGET" and p[1]=="1":return list(map(float,p[3:]))
a=targets(o/"reference-probe.stderr");b0=targets(o/"stochastic-probe.stderr");delta={str(i):y-x for i,(x,y) in enumerate(zip(a,b0)) if abs(y-x)>1e-6};result={"same_first_observation":f[0]["actor_observation"]==ref[0]["actor_observation"],"sampled_actions_8_17":f[0]["accepted_actions"][8:18],"first_target_differences":delta};(o/"stochastic-probe-result.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result,indent=2),flush=True)
if not any(abs(x)>1e-6 for x in result["sampled_actions_8_17"]):raise SystemExit("No sampled new actions reached native rollout")
