from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";o=a/"v15-wholebody-v2-training";b=r/"build/crow-v15-recorded-restart-20261114";keys=("q","v","actor_observation","accepted_actions","body_states","reward","done","termination_reason","outcomes");env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/"v15-checkpoint-effort-prototype"),CROW_EXPERIMENT_GAIT_SMOOTH="1");env.pop("CROW_RECORDED_STATE_RESTART",None);env.pop("CROW_CHECKPOINT_FORK_POLICY",None)
for seed,split in ((20370113,150),(20370127,50)):
 source=a/f"v15-resetfixed-training-checkpoint-source-{seed}-{split}";name=f"checkpoint-{seed}-{split}";out=o/name;out.mkdir(exist_ok=False);c=json.loads((source/"command.json").read_text());c[c.index("--metallib")+1]=str(b/"v15-wholebody-v2-training/neural.metallib");c[c.index("--state-trace")+1]=str(out/"prefix.tsv");c[c.index("--crow-replay-pack")+1]=str(out/"prefix.json");c[c.index("--save-life-checkpoint")+1]=str(out/"life.chk");(out/"command.json").write_text(json.dumps(c,indent=2)+"\n");t=time.time()
 with (out/"stdout").open("w") as so,(out/"stderr").open("w") as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 result={"exit_code":q.returncode,"elapsed":time.time()-t};(out/"result.json").write_text(json.dumps(result,indent=2)+"\n");print(name,result,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
 ref=json.loads((source/"prefix.json").read_text())["payload"]["frames"];got=json.loads((out/"prefix.json").read_text())["payload"]["frames"];assert len(ref)==len(got)==split;d={k:sum(x[k]!=y[k] for x,y in zip(ref,got)) for k in keys};result.update({"mismatched_frames":d,"checkpoint_sha256":hashlib.sha256((out/"life.chk").read_bytes()).hexdigest()});(out/"result.json").write_text(json.dumps(result,indent=2)+"\n");print(name,d,flush=True)
 if any(d.values()):raise SystemExit("training shader prefix mismatch")
