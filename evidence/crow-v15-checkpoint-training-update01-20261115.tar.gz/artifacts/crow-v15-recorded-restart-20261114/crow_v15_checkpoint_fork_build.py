from pathlib import Path
import json,subprocess
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';p=b/'v15-checkpoint-prototype';t=b/'v15-checkpoint-fork-prototype';t.mkdir(exist_ok=False)
s=(a/'task_rollout-v15-checkpoint-prototype.swift').read_text();key='''                try context.restoreLifeCheckpoint(from: URL(fileURLWithPath: path))
            } else {''';assert s.count(key)==1
s=s.replace(key,'''                try context.restoreLifeCheckpoint(from: URL(fileURLWithPath: path))
                // Research-only counterfactual: validate the source policy and
                // snapshot first, then publish a compatible dense candidate.
                if let candidate = ProcessInfo.processInfo.environment["CROW_CHECKPOINT_FORK_POLICY"], !candidate.isEmpty {
                    guard context.policyMemoryWidth == 0 else {
                        throw MetalRoboTaskRolloutError.invalidShape("Checkpoint policy fork requires a dense actor.")
                    }
                    try context.loadPolicy(at: URL(fileURLWithPath: candidate))
                    installedPolicyRevision = context.installedPolicyRevision
                }
            } else {''')
key2='''            output["life_checkpoint_restored"] = options.resumeLifeCheckpoint != nil''';assert s.count(key2)==1;s=s.replace(key2,'''            output["research_counterfactual_policy"] = ProcessInfo.processInfo.environment["CROW_CHECKPOINT_FORK_POLICY"] ?? ""
'''+key2)
src=a/'task_rollout-v15-checkpoint-fork-prototype.swift';src.write_text(s);rec=json.loads((a/'v15-checkpoint-prototype-host-build.json').read_text());cmd=rec['swift_compile']['command'];cmd[cmd.index(str(a/'task_rollout-v15-checkpoint-prototype.swift'))]=str(src);cmd[cmd.index('-o')+1]=str(t/'metalrobo_task_rollout');q=subprocess.run(cmd,cwd=r/'build',text=True,capture_output=True);(a/'v15-checkpoint-fork-prototype-build.json').write_text(json.dumps({'command':cmd,'exit_code':q.returncode,'stderr':q.stderr},indent=2)+'\n');print('swift_compile',q.returncode,q.stderr[-3000:]);raise SystemExit(q.returncode)
