from pathlib import Path
import json,subprocess
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';p=b/'v15-checkpoint-prototype';t=b/'v15-checkpoint-trainer-prototype';t.mkdir(exist_ok=False)
s=(a/'task_train-balance-16.swift').read_text();key='if !options.checkpointLife && options.trainingResume == nil {';assert s.count(key)==1;s=s.replace(key,'if !options.checkpointLife && options.trainingResume == nil && ProcessInfo.processInfo.environment["CROW_RESEARCH_INITIAL_CHECKPOINT"] == nil {',1)
key='''            } else {
                try context.reset(seed: crowPhysicalSeed(options, initialLifeIndex))
            }

            let baseline = context.layout''';assert s.count(key)==1
s=s.replace(key,'''            } else if let checkpoint = ProcessInfo.processInfo.environment["CROW_RESEARCH_INITIAL_CHECKPOINT"],
                      let sourcePolicy = ProcessInfo.processInfo.environment["CROW_RESEARCH_SOURCE_POLICY"] {
                guard options.environments == 1, options.updates == 1,
                      !checkpoint.isEmpty, !sourcePolicy.isEmpty, context.policyMemoryWidth == 0 else {
                    throw MetalRoboTaskRolloutError.invalidShape("Research checkpoint training requires one lane, one update and a dense source actor.")
                }
                // Admit exact source policy and state before switching to the
                // compatible learner policy. Explicitly research-only.
                try context.loadPolicy(at: URL(fileURLWithPath: sourcePolicy))
                try context.restoreLifeCheckpoint(from: URL(fileURLWithPath: checkpoint))
                try context.loadPolicy(at: URL(fileURLWithPath: learner.policyPackPath))
                installedRevision = context.installedPolicyRevision
                guard installedRevision == learner.revision else {
                    throw MetalRoboTaskRolloutError.invalidShape("Research checkpoint learner revision mismatch.")
                }
            } else {
                try context.reset(seed: crowPhysicalSeed(options, initialLifeIndex))
            }

            let baseline = context.layout''')
src=a/'task_train-v15-checkpoint-prototype.swift';src.write_text(s)
cmd=['/usr/bin/swiftc','-O','-swift-version','6','-module-name','metalrobo_task_train_balance','-I',str(r/'include/metalrobo'),'-I',str(r/'include'),'-I',str(r/'matter/include'),str(src),str(r/'apps/CrowEpisodeEvidence.swift'),str(r/'apps/RunInspector.swift'),str(r/'bindings/swift/MetalRoboTaskRollout.swift'),'-L',str(p),'-lmetalrobo','-Xlinker','-rpath','-Xlinker','@loader_path','-Xlinker','-framework','-Xlinker','AppKit','-o',str(t/'metalrobo_task_train')];q=subprocess.run(cmd,cwd=r/'build',text=True,capture_output=True);(a/'v15-checkpoint-trainer-prototype-build.json').write_text(json.dumps({'command':cmd,'exit_code':q.returncode,'stderr':q.stderr},indent=2)+'\n');print('swift_compile',q.returncode,q.stderr[-4000:]);raise SystemExit(q.returncode)
