from pathlib import Path
import json,os,subprocess,hashlib
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';o=a/'v15-checkpoint-fork-parity-50';o.mkdir(exist_ok=False);source=a/'v15-checkpoint-effort-roundtrip-50';base=b/'neural-arrival-phase-history-continuation-update-04.policypack.deployment.policypack';candidate=b/'neural-hard-seed-continuation-02.policypack.deployment.policypack';cmd=json.loads((source/'resume.command.json').read_text());cmd[0]=str(b/'v15-checkpoint-fork-prototype/metalrobo_task_rollout');rows=[]
for name,fork in [('baseline',None),('same_policy',base),('candidate',candidate)]:
 c=cmd.copy();c[c.index('--state-trace')+1]=str(o/(name+'.tsv'));c[c.index('--crow-replay-pack')+1]=str(o/(name+'.json'));env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/'v15-checkpoint-effort-prototype'),CROW_EXPERIMENT_GAIT_SMOOTH='1');env.pop('CROW_RECORDED_STATE_RESTART',None);env.pop('CROW_CHECKPOINT_FORK_POLICY',None)
 if fork:env['CROW_CHECKPOINT_FORK_POLICY']=str(fork)
 (o/(name+'.command.json')).write_text(json.dumps({'argv':c,'fork_policy':str(fork) if fork else None},indent=2)+'\n')
 with (o/(name+'.stdout')).open('w') as so,(o/(name+'.stderr')).open('w') as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 rows.append({'name':name,'exit_code':q.returncode});print(name,q.returncode,flush=True)
 if q.returncode:(o/'results.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(q.returncode)
frames={name:json.loads((o/(name+'.json')).read_text())['payload']['frames'] for name in ('baseline','same_policy','candidate')};checks={}
for k in ('q','v','actor_observation','accepted_actions','body_states','reward','done','termination_reason','outcomes'):
 mismatch=[i+1 for i,(x,y) in enumerate(zip(frames['baseline'],frames['same_policy'])) if x[k]!=y[k]];checks[k]={'first_mismatch':mismatch[0] if mismatch else None,'count':len(mismatch)}
a=frames['baseline'][0];z=frames['candidate'][0];report={'rows':rows,'same_policy_fork':checks,'candidate_first_observation_equal':a['actor_observation']==z['actor_observation'],'candidate_first_action_max_difference':max(abs(x-y) for x,y in zip(a['accepted_actions'],z['accepted_actions'])),'source_checkpoint_sha256':hashlib.sha256((source/'life.chk').read_bytes()).hexdigest(),'source_policy_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'candidate_policy_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'scope':'counterfactual policy switch at a reconstructed perch checkpoint, not original 48-second run'};(o/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
