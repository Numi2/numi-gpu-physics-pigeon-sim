from pathlib import Path
import json,os,subprocess,hashlib
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';o=a/'v15-checkpoint-fork-paired-300';o.mkdir(exist_ok=False);source=a/'v15-checkpoint-effort-roundtrip-50';base=b/'neural-arrival-phase-history-continuation-update-04.policypack.deployment.policypack';candidate=b/'neural-hard-seed-continuation-02.policypack.deployment.policypack';cmd=json.loads((source/'resume.command.json').read_text());cmd[0]=str(b/'v15-checkpoint-fork-prototype/metalrobo_task_rollout');rows=[]
for name,fork in [('baseline',None),('candidate',candidate)]:
 c=cmd.copy();c[c.index('--steps')+1]='300';c[c.index('--state-trace')+1]=str(o/(name+'.tsv'));c[c.index('--crow-replay-pack')+1]=str(o/(name+'.json'));env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/'v15-checkpoint-effort-prototype'),CROW_EXPERIMENT_GAIT_SMOOTH='1');env.pop('CROW_RECORDED_STATE_RESTART',None);env.pop('CROW_CHECKPOINT_FORK_POLICY',None)
 if fork:env['CROW_CHECKPOINT_FORK_POLICY']=str(fork)
 (o/(name+'.command.json')).write_text(json.dumps({'argv':c,'fork_policy':str(fork) if fork else None},indent=2)+'\n')
 with (o/(name+'.stdout')).open('w') as so,(o/(name+'.stderr')).open('w') as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 row={'name':name,'exit_code':q.returncode};rows.append(row);print(row,flush=True)
 if q.returncode:(o/'results.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(q.returncode)
frames={n:json.loads((o/(n+'.json')).read_text())['payload']['frames'] for n in ('baseline','candidate')};summary={}
for name,fs in frames.items():
 dones=[{'relative_step':i+1,'absolute_step':i+51,'reason':x['termination_reason']} for i,x in enumerate(fs) if x['done']];first=dones[0] if dones else None;end=first['relative_step'] if first else len(fs);valid=fs[:end];summary[name]={'first_done':first,'all_done':dones,'max_tilt_pre_or_at_done':max(f['tilt'] for f in valid),'final_pre_or_at_done_height':valid[-1]['root_height']}
report={'source_checkpoint_sha256':hashlib.sha256((source/'life.chk').read_bytes()).hexdigest(),'source_policy_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'candidate_policy_sha256':hashlib.sha256(candidate.read_bytes()).hexdigest(),'results':summary,'same_first_observation':frames['baseline'][0]['actor_observation']==frames['candidate'][0]['actor_observation'],'scope':'checkpoint after 50 intervals of a reconstructed, relocated branch fixture with scripted carrier; comparison uses consumed seed'};(o/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
