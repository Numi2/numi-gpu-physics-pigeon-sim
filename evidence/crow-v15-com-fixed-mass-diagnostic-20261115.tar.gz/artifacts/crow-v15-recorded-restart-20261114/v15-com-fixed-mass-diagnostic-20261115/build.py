from pathlib import Path
import json,hashlib,subprocess
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';o=a/'v15-com-fixed-mass-diagnostic-20261115';b=r/'build/crow-v15-recorded-restart-20261114/v15-com-fixed-mass-diagnostic-20261115';o.mkdir(exist_ok=False);b.mkdir(exist_ok=False)
source=a/'v15-com-signal-diagnostic-20261115/com_signal_diagnostic.metal';massfile=a/'v15-perch-mass-observer-20261115/mass.txt';lines=massfile.read_text().splitlines();assert len(lines)==35 and all(int(x.split()[0])==i for i,x in enumerate(lines));masses=[float(x.split()[2]) for x in lines];assert abs(sum(masses)-.45006)<1e-6
s=source.read_text();old='''        for (uint bi=robotFirst;bi<robotEnd;++bi) {
            const MRBodyStateGPU body=bodyStates[bodyBase+bi];
            const float inv=body.linearVelocityAndInverseMass.w;
            if (inv>0.0f && isfinite(inv)) {
                const float m=1.0f/inv;
                mass+=m; comX+=m*body.position.x; velX+=m*body.linearVelocityAndInverseMass.x;
            }
        }''';assert s.count(old)==1
values=', '.join(f'{m:.12g}f' if '.' in f'{m:.12g}' or 'e' in f'{m:.12g}' else f'{m:.12g}.0f' for m in masses)
new='''        // Exact masses extracted from the source-identified 35-body v15 model; research fixture only.
        const float v15Masses[35]={'''+values+'''};
        if (robotEnd-robotFirst==35u) for (uint bi=robotFirst;bi<robotEnd;++bi) {
            const MRBodyStateGPU body=bodyStates[bodyBase+bi];
            const float m=v15Masses[bi-robotFirst];
            mass+=m; comX+=m*body.position.x; velX+=m*body.linearVelocityAndInverseMass.x;
        }'''
s=s.replace(old,new);src=o/'com_fixed_mass_diagnostic.metal';src.write_text(s);air=b/'com_fixed_mass_diagnostic.air';lib=b/'com_fixed_mass_diagnostic.metallib';record=json.loads((a/'v15-wholebody-v3/build.json').read_text())['neural'];cc=record['compile']['argv'].copy();cc[cc.index('-c')+1]=str(src);cc[cc.index('-o')+1]=str(air);ld=record['link']['argv'].copy();ld[ld.index('-o')+1]=str(lib);ld=[str(air) if x.endswith('/v15-wholebody-v3/neural.air') else x for x in ld];assert str(air) in ld;out={}
for kind,cmd in [('compile',cc),('link',ld)]:
 p=subprocess.run(cmd,cwd=r,text=True,capture_output=True);out[kind]={'argv':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr};(o/'build.json').write_text(json.dumps(out,indent=2)+'\n');print(kind,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
out['sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source,massfile,src,air,lib)};out['mass_sum']=sum(masses);(o/'build.json').write_text(json.dumps(out,indent=2)+'\n')
