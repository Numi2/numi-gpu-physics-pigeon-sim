from pathlib import Path
import json,math
A=Path('/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114');stem=A/'v15-com-fixed-mass-diagnostic-eval-20261115/20370113-com_fixed_mass_diagnostic-620';control=A/'v15-coupled-wing-hip-disturbance-eval-20261115/20370113-hip_pulse_pos-1000';actual=json.loads(stem.with_suffix('.json').read_text())['payload']['frames'];frames=json.loads(control.with_suffix('.json').read_text())['payload']['frames'];masses=[float(x.split()[2]) for x in (A/'v15-perch-mass-observer-20261115/mass.txt').read_text().splitlines()];total=sum(masses);assert len(masses)==35
contacts={}
with control.with_suffix('.stderr').open() as f:
 for line in f:
  if not line.startswith('CROW_SCENE_CONTACT '):continue
  x=line.split();t=int(x[1]);sub=int(x[2]);a,b=int(x[4]),int(x[5]);bird=a if b==40 else b if a==40 else -1
  if not(550<=t<=620 and sub==15 and (bird in (11,15) or 19<=bird<=34)):continue
  n,j,k=map(float,x[6:9]);nx,ny,nz,tx,ty,tz=map(float,x[13:19]);sg=1 if a==40 else -1
  if n<=0:continue
  z=sg*(nz*n+tz*j+(nx*ty-ny*tx)*k);up,wx=contacts.get(t,(0.,0.));contacts[t]=(up+z,wx+z*float(x[9]))
def signal(t):
 body=frames[t-1]['body_states'];up,wx=contacts.get(t,(0,0));com=sum(m*body[i*13] for i,m in enumerate(masses))/total;vx=sum(m*body[i*13+7] for i,m in enumerate(masses))/total
 return max(-.2,min(.2,com-wx/up-.0236+.1*vx)) if up>1e-8 else 0.
rows=[]
for t in range(551,621):
 phase=(t-551)%5;got=actual[t-1]['reward'];want=[lambda:total,lambda:contacts.get(t,(0,0))[0],lambda:40.,lambda:signal(t),lambda:signal(t-1)][phase]();rows.append({'step':t,'field':['mass','last_substep_upward_impulse','branch_id','signal','action_path_signal'][phase],'recorded':got,'independent':want,'error':got-want})
parity={k:sum(a[k]!=b[k] for a,b in zip(frames,actual)) for k in ('q','v','actor_observation','accepted_actions','body_states','reward','done')};output={'frames':len(actual),'parity_mismatches':parity,'tolerance':'mass 1e-6 kg, impulse 1e-6 N s, branch id exact, signal and action snapshot 1e-4 m; CPU reconstruction uses double and GPU uses float','samples':rows};(stem.parent/'independent-telemetry-check.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
