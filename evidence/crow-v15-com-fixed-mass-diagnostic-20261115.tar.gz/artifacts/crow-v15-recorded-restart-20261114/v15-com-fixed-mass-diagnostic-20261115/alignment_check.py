from pathlib import Path
import json,math
A=Path('/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114');stem=A/'v15-com-fixed-mass-diagnostic-eval-20261115/20370113-com_fixed_mass_diagnostic-620';control=A/'v15-coupled-wing-hip-disturbance-eval-20261115/20370113-hip_pulse_pos-1000';actual=json.loads(stem.with_suffix('.json').read_text())['payload']['frames'];frames=json.loads(control.with_suffix('.json').read_text())['payload']['frames'];m=[float(x.split()[2]) for x in (A/'v15-perch-mass-observer-20261115/mass.txt').read_text().splitlines()];total=sum(m);cs={}
with control.with_suffix('.stderr').open() as f:
 for line in f:
  if not line.startswith('CROW_SCENE_CONTACT '):continue
  x=line.split();t=int(x[1]);sub=int(x[2]);a,b=int(x[4]),int(x[5]);bird=a if b==40 else b if a==40 else -1
  if not(540<=t<=625 and sub==15 and (bird in (11,15) or 19<=bird<=34)):continue
  n,j,k=map(float,x[6:9]);nx,ny,nz,tx,ty,tz=map(float,x[13:19]);sg=1 if a==40 else -1
  if n<=0:continue
  z=sg*(nz*n+tz*j+(nx*ty-ny*tx)*k);up,wx=cs.get(t,(0.,0.));cs[t]=(up+z,wx+z*float(x[9]))
rows=[]
for ob in range(-2,3):
 for oc in range(-2,3):
  es=[]
  for t in range(554,620,5):
   body=frames[t+ob-1]['body_states'];up,wx=cs.get(t+oc,(0,0));com=sum(w*body[i*13] for i,w in enumerate(m))/total;v=sum(w*body[i*13+7] for i,w in enumerate(m))/total;pred=max(-.2,min(.2,com-wx/up-.0236+.1*v)) if up>1e-8 else 0;es.append(actual[t-1]['reward']-pred)
  rows.append({'body_step_offset':ob,'contact_step_offset':oc,'rms':math.sqrt(sum(e*e for e in es)/len(es)),'max_abs':max(map(abs,es))})
rows.sort(key=lambda x:x['rms']);out={'method':'post hoc diagnostic only, no validation promotion','fits':rows};(stem.parent/'alignment-offset-screen.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(rows[:8],indent=2))
