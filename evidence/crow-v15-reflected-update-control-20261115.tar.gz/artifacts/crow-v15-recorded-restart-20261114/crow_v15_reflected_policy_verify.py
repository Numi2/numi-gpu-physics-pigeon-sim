from pathlib import Path
import json,numpy as np
from metalrobo.mlx_policy_learning import read_policy_pack
r=Path("/Users/n/Developer/numi-crow-rl-20261107");b=r/"build/crow-v15-recorded-restart-20261114";a=r/"artifacts/crow-v15-recorded-restart-20261114";lib=b/"toe-sensing-experiment-host/libmetalrobo.dylib";x=read_policy_pack(b/"neural-arrival-phase-history-continuation-update-04.policypack",library_path=lib);z=read_policy_pack(b/"v15-reflected-lr1000x-policy.policypack",library_path=lib);c={"mean":np.array_equal(x.effective_observation_mean,z.effective_observation_mean),"scale":np.array_equal(x.effective_observation_inverse_standard_deviation,z.effective_observation_inverse_standard_deviation),"contract":all(getattr(x,k)==getattr(z,k) for k in ("world_fingerprint","task_fingerprint","observation_fingerprint","action_fingerprint"))}
for i,(u,v) in enumerate(zip(x.layers,z.layers)):
 mask=np.zeros(u.weights.shape,bool)
 if i==0:mask[-24:,216:228]=True
 elif i<len(x.layers)-1:mask[-24:,-24:]=True
 else:mask[:8,-24:]=True
 c[f"layer_{i}_protected"]=np.array_equal(u.weights[~mask],v.weights[~mask]);c[f"layer_{i}_bias"]=np.array_equal(u.bias,v.bias)
out={k:bool(v) for k,v in c.items()};(a/"v15-reflected-lr1000x-policy-verification.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2));assert all(c.values())
