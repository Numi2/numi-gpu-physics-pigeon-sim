from pathlib import Path
import json,hashlib,numpy as np,mlx.core as mx
from metalrobo.mlx_policy_learning import MLXPolicyLearner,read_policy_pack,read_policy_rollout_pack
r=Path("/Users/n/Developer/numi-crow-rl-20261107");b=r/"build/crow-v15-recorded-restart-20261114";a=r/"artifacts/crow-v15-recorded-restart-20261114";lib=b/"toe-sensing-experiment-host/libmetalrobo.dylib";src=b/"neural-arrival-phase-history-continuation-update-04.policypack";train=b/"v15-resetfixed-training-20370113-horizon256-lr1000x-fresh-v2.policypack";dst=b/"v15-reflected-lr1000x-policy.policypack";assert not dst.exists();x=read_policy_pack(src,library_path=lib);y=read_policy_pack(train,library_path=lib);l=MLXPolicyLearner.from_policy_pack(src,library_path=lib);assert len(x.layers)==len(y.layers)==len(l.model.actor.layers)
for i,(u,v,layer) in enumerate(zip(x.layers,y.layers,l.model.actor.layers)):
 w=np.array(layer.weight);mask=np.zeros(w.shape,bool)
 if i==0:mask[-24:,216:228]=True
 elif i<len(x.layers)-1:mask[-24:,-24:]=True
 else:mask[:8,-24:]=True
 assert np.array_equal(u.weights[~mask],v.weights[~mask]) and np.array_equal(u.bias,v.bias)
 w[mask]=2*u.weights[mask]-v.weights[mask];layer.weight=mx.array(w);mx.eval(layer.weight)
l.write_policy_pack(dst,stochastic=False,library_path=lib);z=read_policy_pack(dst,library_path=lib);obs=read_policy_rollout_pack(b/"v15-resetfixed-training-20370113-horizon256-lr1000x-fresh-v2.rollout",library_path=lib).actor_observations.reshape(-1,828);scale=np.array([.08]*4+[.25]*4);du=(y.actions(obs)[:,:8]-x.actions(obs)[:,:8])*scale;dr=(z.actions(obs)[:,:8]-x.actions(obs)[:,:8])*scale
out={"base_sha256":hashlib.sha256(src.read_bytes()).hexdigest(),"trained_sha256":hashlib.sha256(train.read_bytes()).hexdigest(),"reflected_sha256":hashlib.sha256(dst.read_bytes()).hexdigest(),"trained_target_delta_rms_rad":np.sqrt(np.mean(du*du,axis=0)).tolist(),"reflected_target_delta_rms_rad":np.sqrt(np.mean(dr*dr,axis=0)).tolist(),"per_action_correlation":[float(np.corrcoef(du[:,i],dr[:,i])[0,1]) for i in range(8)],"note":"Reflection in the permitted network weight coordinates, not an exact reversal of nonlinear policy actions; compare both on the same retained observations. No protected weights, biases, normalizer or actuator bounds changed."};(a/"v15-reflected-lr1000x-policy.json").write_text(json.dumps(out,indent=2)+"\n");print(json.dumps(out,indent=2))
