from pathlib import Path
import json,subprocess,hashlib
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';record=json.loads((a/'neural-arrival-phase-history-control-build.json').read_text());results={}
for kind in ('eval','training'):
 src=a/f'neural-arrival-phase-history-control-{kind}.metal';s=src.read_text();old='if (6u>=2u && (i==8u || i==9u) && state.episode.x>0u) continue;';new='if (6u>=2u && (i==8u || i==9u) && state.episode.x>0u && !(state.episode.z==10u && state.episode.x==2400u)) continue;';assert s.count(old)==1;s=s.replace(old,new);out=a/f'neural-arrival-reset-target-fixed-{kind}.metal';out.write_text(s);air=b/f'neural-arrival-reset-target-fixed-{kind}.air';lib=b/f'neural-arrival-reset-target-fixed-{kind}.metallib';compile=record['variants'][kind]['compile'].copy();compile[compile.index('-c')+1]=str(out);compile[compile.index('-o')+1]=str(air);link=record['variants'][kind]['link'].copy();link[link.index('-o')+1]=str(lib)
 for i,x in enumerate(link):
  if x.endswith(f'neural-arrival-phase-history-control-{kind}.air'):link[i]=str(air)
 results[kind]={}
 for label,cmd in [('compile',compile),('link',link)]:
  q=subprocess.run(cmd,cwd=r,text=True,capture_output=True);results[kind][label]={'command':cmd,'exit_code':q.returncode,'stderr':q.stderr};print(kind,label,q.returncode,q.stderr[-2000:],flush=True)
  (a/'neural-arrival-reset-target-fixed-build.json').write_text(json.dumps(results,indent=2)+'\n')
  if q.returncode:raise SystemExit(q.returncode)
 results[kind]['sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (src,out,air,lib)}
(a/'neural-arrival-reset-target-fixed-build.json').write_text(json.dumps(results,indent=2)+'\n')
