from pathlib import Path
import json,os,subprocess
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';b=r/'build/crow-v15-recorded-restart-20261114';out=a/'v15-warmup-reset-contamination-probe';out.mkdir(exist_ok=False);source=a/'v15-checkpoint-effort-roundtrip-50';base=json.loads((source/'prefix.command.json').read_text());env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/'v15-checkpoint-effort-prototype'),CROW_EXPERIMENT_GAIT_SMOOTH='1',CROW_SUBSTEP_TRACE='1');env.pop('CROW_RECORDED_STATE_RESTART',None)
for name in ('warmup','checkpoint'):
 c=base.copy();c[c.index('--steps')+1]='1';c[c.index('--state-trace')+1]=str(out/(name+'.tsv'));c[c.index('--crow-replay-pack')+1]=str(out/(name+'.json'));i=c.index('--save-life-checkpoint')
 if name=='warmup':del c[i:i+2]
 else:c[i+1]=str(out/'one.chk')
 (out/(name+'.command.json')).write_text(json.dumps(c,indent=2)+'\n')
 with (out/(name+'.stdout')).open('w') as so,(out/(name+'.stderr')).open('w') as se:q=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 print(name,q.returncode,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
x=json.loads((out/'warmup.json').read_text())['payload']['frames'][0];y=json.loads((out/'checkpoint.json').read_text())['payload']['frames'][0]
def lines(name,prefix,step):
 return [l for l in (out/(name+'.stderr')).read_text().splitlines() if l.startswith(prefix+' '+str(step)+' ')]
report={'same_first_observation':x['actor_observation']==y['actor_observation'],'same_first_action':x['accepted_actions']==y['accepted_actions'],'q_max_difference':max(abs(u-v) for u,v in zip(x['q'],y['q'])),'v_max_difference':max(abs(u-v) for u,v in zip(x['v'],y['v'])),'warmup_first_recorded_wing_target':lines('warmup','CROW_WING_TARGET_PAIR',2),'checkpoint_first_wing_target':lines('checkpoint','CROW_WING_TARGET_PAIR',1),'warmup_first_wing_effort':lines('warmup','CROW_WING_EFFORT',2)[:1],'checkpoint_first_wing_effort':lines('checkpoint','CROW_WING_EFFORT',1)[:1]};(out/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
