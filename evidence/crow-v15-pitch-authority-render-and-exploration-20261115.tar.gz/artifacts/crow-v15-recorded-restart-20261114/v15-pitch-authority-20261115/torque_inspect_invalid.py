from pathlib import Path
import json,numpy as np
p=Path("/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114/v15-pitch-authority-20261115");f=json.loads((p/"zero.json").read_text())["payload"]["frames"];out={}
with (p/"zero.stderr").open() as fin:
 for s in fin:
  x=s.split()
  if not x or x[0]!="CROW_SCENE_CONTACT":continue
  t=int(x[1]);a,b=map(int,x[4:6]);
  if t>208 or not ((a<35 and b==40) or (b<35 and a==40)):continue
  z=np.array(list(map(float,x[9:12])));normal=np.array(list(map(float,x[12:15])));tan=np.array(list(map(float,x[15:18])));n,j1,j2=map(float,x[6:9]);imp=(-1 if b==40 else 1)*(n*normal+j1*tan+j2*np.cross(normal,tan));q=f[t-1]["q"];r=z-np.array(q[:3]);moment=np.cross(r,imp);row=out.setdefault(t,[0.,0.,0.,0.]);row[0]+=moment[1];row[1]+=imp[2];row[2]+=imp[0];row[3]+=1
for start in (1,41,81,121,151,181,201):
 end=min(start+19,208);arr=np.array([out[t] for t in range(start,end+1)]);print(start,end,"root_pitchq",round(f[end-1]["q"][4],4),"root_x",round(f[end-1]["q"][0],4),"y_moment_impulse",round(arr[:,0].mean(),7),"vertical_impulse",round(arr[:,1].mean(),6),"forward_impulse",round(arr[:,2].mean(),6))
