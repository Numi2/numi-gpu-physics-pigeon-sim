from pathlib import Path
import json,os,subprocess,time,hashlib
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';o=a/'v15-com-component-diagnostic-20261115';b=r/'build/crow-v15-recorded-restart-20261114';source=a/'v15-wholebody-v3';keys=('q','v','actor_observation','accepted_actions','body_states','reward','done','termination_reason','outcomes');ref=json.loads((source/'neural-prefix.json').read_text())['payload']['frames'];env=dict(os.environ,DYLD_LIBRARY_PATH=str(b/'v15-checkpoint-effort-prototype'),CROW_EXPERIMENT_GAIT_SMOOTH='1');env.pop('CROW_RECORDED_STATE_RESTART',None);env.pop('CROW_CHECKPOINT_FORK_POLICY',None)
for variant in ('com_component_diagnostic',):
 c=json.loads((source/'neural-prefix.command.json').read_text())['argv'];stem=o/(variant+'-prefix')
 for k,v in (('--metallib',b/f'v15-com-component-diagnostic-20261115/{variant}.metallib'),('--state-trace',str(stem)+'.tsv'),('--crow-replay-pack',str(stem)+'.json'),('--save-life-checkpoint',o/(variant+'.chk'))):c[c.index(k)+1]=str(v)
 (o/(variant+'-prefix.command.json')).write_text(json.dumps(c,indent=2)+'\n');t=time.time()
 with (o/(variant+'-prefix.stdout')).open('w') as so,(o/(variant+'-prefix.stderr')).open('w') as se:p=subprocess.run(c,cwd=r,env=env,stdout=so,stderr=se)
 result={'exit_code':p.returncode,'elapsed':time.time()-t};print(variant,result,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 got=json.loads((o/(variant+'-prefix.json')).read_text())['payload']['frames'];assert len(ref)==len(got)==49;result['mismatched_frames']={k:sum(x[k]!=y[k] for x,y in zip(ref,got)) for k in keys};result['checkpoint_sha256']=hashlib.sha256((o/(variant+'.chk')).read_bytes()).hexdigest();(o/(variant+'-prefix-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(result,flush=True)
 if any(result['mismatched_frames'].values()):raise SystemExit('shader prefix mismatch')
