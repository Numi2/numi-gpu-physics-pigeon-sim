from pathlib import Path
import json
r=Path("/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114");normal=r/"v15-resetfixed-lr30x-continuation04-evaluation-20370113-250";debug=r/"v15-gate-telemetry-v2-continuation04-evaluation-20370113-250";report={}
for n in ("baseline","candidate"):
 a=json.loads((normal/(n+".json")).read_text())["payload"]["frames"];b=json.loads((debug/(n+".json")).read_text())["payload"]["frames"];fields=("q","v","actor_observation","accepted_actions","body_states","reward","done","termination_reason");diff={k:[i+1 for i,(x,y) in enumerate(zip(a,b)) if x[k]!=y[k]] for k in fields};assert len(a)==len(b) and all(not v for v in diff.values())
 end=next((i+1 for i,f in enumerate(b) if f["done"]),len(b));vals=[]
 for i,f in enumerate(b[:end]):
  p=int(f["outcomes"]["approach_pitch_warning_fraction"]);lr,rr=p&63,(p>>6)&63;loads=(p>>20)&3;vals.append({"step":i+1,"left_ramp":lr,"right_ramp":rr,"load_bits":loads,"gate_enabled":loads==3 and lr>=24 and rr>=24})
 off=[v for v in vals if not v["gate_enabled"]];report[n]={"first_done":end,"dynamics_match_all_250_frames":True,"gate_enabled_steps_before_and_including_fall":end-len(off),"gate_disabled_steps":off,"samples":[vals[i-1] for i in (1,50,100,150,180,200,end) if i<=end]}
report["scope"]="Diagnostic shader stores post-step gate bits in the warning outcome channel only; dynamics match the noninstrumented replay, but post-step state is next-step action input. One consumed development start; not proof about other states.";(debug/"gate-analysis.json").write_text(json.dumps(report,indent=2)+"\n");print(json.dumps(report,indent=2))
