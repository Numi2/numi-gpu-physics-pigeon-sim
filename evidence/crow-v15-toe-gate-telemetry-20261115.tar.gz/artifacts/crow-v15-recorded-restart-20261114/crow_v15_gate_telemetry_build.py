from pathlib import Path
import json,subprocess,hashlib
r=Path("/Users/n/Developer/numi-crow-rl-20261107");a=r/"artifacts/crow-v15-recorded-restart-20261114";b=r/"build/crow-v15-recorded-restart-20261114";src=a/"neural-arrival-reset-target-fixed-eval.metal";s=src.read_text();old="""    transitions[transitionIndex] = transition;
}""";new="""    // Research-only output telemetry: 12 ramp bits and 2 foot-load bits.
    // No task state, action, reward or physics is modified.
    transition.navigation.x = float(state.status.w & (4095u | (1u<<20) | (1u<<21)));
    transitions[transitionIndex] = transition;
}""";assert s.count(old)==1;s=s.replace(old,new);out=a/"neural-arrival-resetfixed-gate-telemetry-eval.metal";out.write_text(s)
rec=json.loads((a/"neural-arrival-phase-history-control-build.json").read_text())["variants"]["eval"];air=b/"neural-arrival-resetfixed-gate-telemetry-eval.air";lib=b/"neural-arrival-resetfixed-gate-telemetry-eval.metallib";c=rec["compile"].copy();c[c.index("-c")+1]=str(out);c[c.index("-o")+1]=str(air);link=rec["link"].copy();link[link.index("-o")+1]=str(lib)
for i,x in enumerate(link):
 if x.endswith("neural-arrival-phase-history-control-eval.air"):link[i]=str(air)
result={}
for key,cmd in (("compile",c),("link",link)):
 q=subprocess.run(cmd,cwd=r,capture_output=True,text=True);result[key]={"command":cmd,"exit_code":q.returncode,"stderr":q.stderr};(a/"neural-arrival-resetfixed-gate-telemetry-build.json").write_text(json.dumps(result,indent=2)+"\n");print(key,q.returncode,flush=True)
 if q.returncode:raise SystemExit(q.returncode)
result["sha256"]={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (src,out,air,lib)};(a/"neural-arrival-resetfixed-gate-telemetry-build.json").write_text(json.dumps(result,indent=2)+"\n")
p=(a/"crow_v15_resetfixed_checkpoint_multi.py").read_text().replace("v15-resetfixed-checkpoint-roundtrip-", "v15-gate-telemetry-checkpoint-roundtrip-").replace("neural-arrival-reset-target-fixed-eval.metallib", "neural-arrival-resetfixed-gate-telemetry-eval.metallib")
(a/"crow_v15_gate_telemetry_checkpoint.py").write_text(p)
p=(a/"crow_v15_resetfixed_lr30x_continuation_evaluate.py").read_text().replace("v15-resetfixed-checkpoint-roundtrip-", "v15-gate-telemetry-checkpoint-roundtrip-").replace("v15-resetfixed-lr30x-continuation04-evaluation-", "v15-gate-telemetry-continuation04-evaluation-")
(a/"crow_v15_gate_telemetry_evaluate.py").write_text(p)
