from pathlib import Path
import json,hashlib,subprocess
r=Path('/Users/n/Developer/numi-crow-rl-20261107');a=r/'artifacts/crow-v15-recorded-restart-20261114';o=a/'v15-com-finite-diagnostic-20261115';b=r/'build/crow-v15-recorded-restart-20261114/v15-com-finite-diagnostic-20261115';o.mkdir(exist_ok=False);b.mkdir(exist_ok=False);source=a/'v15-com-component-diagnostic-20261115/com_component_diagnostic.metal';s=source.read_text();needle='    const float diagnosticActionSeenSignal=state.airReturnTracking.z;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    const float diagnosticPreviousCom=state.airReturnTracking.w;')
needle='if (state.episode.z==10u && state.navigation.z>=5.0f && state.episode.x>=3000u && dispatch.counts.w==40u) {';assert s.count(needle)==1;s=s.replace(needle,needle.replace('>=3000u','>=2999u'))
old='diagnosticValues=float4(mass>0.0f ? comX/mass : 0.0f, mass>0.0f ? velX/mass : 0.0f, abs(totalUp)>1.0e-8f ? weightedX/totalUp : 0.0f, totalUp);';new='''const float currentCom=mass>0.0f ? comX/mass : 0.0f;
        const float finiteVelocity=(currentCom-diagnosticPreviousCom)/dispatch.timing.x;
        diagnosticValues=float4(currentCom,diagnosticPreviousCom,finiteVelocity,abs(totalUp)>1.0e-8f ? weightedX/totalUp : 0.0f);
        // Research-only scratch; this overwrites cumulative episode tracking evidence.
        state.airReturnTracking.w=currentCom;''';assert s.count(old)==1;s=s.replace(old,new)
src=o/'com_finite_diagnostic.metal';src.write_text(s);air=b/'com_finite_diagnostic.air';lib=b/'com_finite_diagnostic.metallib';record=json.loads((a/'v15-wholebody-v3/build.json').read_text())['neural'];cc=record['compile']['argv'].copy();cc[cc.index('-c')+1]=str(src);cc[cc.index('-o')+1]=str(air);ld=record['link']['argv'].copy();ld[ld.index('-o')+1]=str(lib);ld=[str(air) if x.endswith('/v15-wholebody-v3/neural.air') else x for x in ld];assert str(air) in ld;out={}
for kind,cmd in [('compile',cc),('link',ld)]:
 p=subprocess.run(cmd,cwd=r,text=True,capture_output=True);out[kind]={'argv':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr};(o/'build.json').write_text(json.dumps(out,indent=2)+'\n');print(kind,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
out['sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (source,src,air,lib)};(o/'build.json').write_text(json.dumps(out,indent=2)+'\n')
