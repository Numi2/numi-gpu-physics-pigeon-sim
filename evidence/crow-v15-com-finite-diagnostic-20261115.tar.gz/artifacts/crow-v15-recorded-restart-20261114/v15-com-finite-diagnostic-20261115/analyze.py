from pathlib import Path
import json
A=Path('/Users/n/Developer/numi-crow-rl-20261107/artifacts/crow-v15-recorded-restart-20261114');stem=A/'v15-com-finite-diagnostic-eval-20261115/20370113-com_finite_diagnostic-620';control=A/'v15-coupled-wing-hip-disturbance-eval-20261115/20370113-hip_pulse_pos-1000';actual=json.loads(stem.with_suffix('.json').read_text())['payload']['frames'];frames=json.loads(control.with_suffix('.json').read_text())['payload']['frames'];m=[float(x.split()[2]) for x in (A/'v15-perch-mass-observer-20261115/mass.txt').read_text().splitlines()];total=sum(m);cs={}
with control.with_suffix('.stderr').open() as f:
 for line in f:
  if not line.startswith('CROW_SCENE_CONTACT '):continue
  x=line.split();t=int(x[1]);sub=int(x[2]);a,b=int(x[4]),int(x[5]);bird=a if b==40 else b if a==40 else -1
  if not(550<=t<=620 and sub==15 and (bird in (11,15) or 19<=bird<=34)):continue
  n,j,k=map(float,x[6:9]);nx,ny,nz,tx,ty,tz=map(float,x[13:19]);sg=1 if a==40 else -1
  if n<=0:continue
  z=sg*(nz*n+tz*j+(nx*ty-ny*tx)*k);up,wx=cs.get(t,(0.,0.));cs[t]=(up+z,wx+z*float(x[9]))
rows=[]
for t in range(551,621):
 body=frames[t-1]['body_states'];com=sum(w*body[i*13] for i,w in enumerate(m))/total;v=sum(w*body[i*13+7] for i,w in enumerate(m))/total;up,wx=cs.get(t,(0,0));point=wx/up if abs(up)>1e-8 else 0;prevbody=frames[t-2]['body_states'];prevcom=sum(w*prevbody[i*13] for i,w in enumerate(m))/total;finite=(com-prevcom)/0.02;phase=(t-551)%4;want=[com,prevcom,finite,point][phase];got=actual[t-1]['reward'];rows.append({'step':t,'field':['com_x','previous_com_x','finite_difference_velocity','impulse_weighted_x'][phase],'recorded':got,'independent':want,'error':got-want})
parity={k:sum(a[k]!=b[k] for a,b in zip(frames,actual)) for k in ('q','v','actor_observation','accepted_actions','body_states','reward','done')};out={'frames':len(actual),'parity_mismatches':parity,'alignment':'accepted replay frame and recorded final contact substep at same control step','samples':rows};(stem.parent/'finite-telemetry-check.json').write_text(json.dumps(out,indent=2)+'\n');print('parity',parity)
for name in ('com_x','previous_com_x','finite_difference_velocity','impulse_weighted_x'):
 vals=[r for r in rows if r['field']==name];worst=max(vals,key=lambda r:abs(r['error']));print(name,'max_abs_error',abs(worst['error']),'worst',worst)
